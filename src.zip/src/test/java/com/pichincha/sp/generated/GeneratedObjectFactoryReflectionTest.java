package com.pichincha.sp.generated;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static org.assertj.core.api.Assertions.assertThat;

class GeneratedObjectFactoryReflectionTest {

    @Test
    void shouldInstantiateGeneratedObjectFactoryAndCreateObjects() throws Exception {
        Class<?> objectFactoryClass = Class.forName("com.pichincha.sp.generated.ObjectFactory");
        Constructor<?> constructor = objectFactoryClass.getDeclaredConstructor();
        constructor.setAccessible(true);
        Object objectFactory = constructor.newInstance();

        int invokedMethods = 0;
        for (Method method : objectFactoryClass.getDeclaredMethods()) {
            if (!method.getName().startsWith("create") || Modifier.isStatic(method.getModifiers())) {
                continue;
            }

            Object result;
            if (method.getParameterCount() == 0) {
                result = method.invoke(objectFactory);
            } else {
                Object[] args = new Object[method.getParameterCount()];
                Class<?>[] parameterTypes = method.getParameterTypes();
                for (int index = 0; index < parameterTypes.length; index++) {
                    args[index] = defaultValue(parameterTypes[index]);
                }
                result = method.invoke(objectFactory, args);
            }

            assertThat(result).isNotNull();
            invokedMethods++;
        }

        assertThat(invokedMethods).isGreaterThan(5);
    }

    private Object defaultValue(Class<?> type) {
        if (type.equals(String.class)) {
            return "value";
        }
        if (type.equals(boolean.class) || type.equals(Boolean.class)) {
            return false;
        }
        if (type.equals(int.class) || type.equals(Integer.class)) {
            return 0;
        }
        if (type.equals(long.class) || type.equals(Long.class)) {
            return 0L;
        }
        if (type.equals(double.class) || type.equals(Double.class)) {
            return 0D;
        }
        if (type.equals(float.class) || type.equals(Float.class)) {
            return 0F;
        }
        if (type.equals(short.class) || type.equals(Short.class)) {
            return (short) 0;
        }
        if (type.equals(byte.class) || type.equals(Byte.class)) {
            return (byte) 0;
        }
        if (type.equals(char.class) || type.equals(Character.class)) {
            return 'a';
        }
        return null;
    }
}
