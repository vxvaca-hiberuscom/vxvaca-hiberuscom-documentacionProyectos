package com.pichincha.sp.application.service.impl;

import com.pichincha.sp.application.constants.ApplicationBusinessConstants;
import com.pichincha.sp.application.port.output.DemographicsCorePort;
import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProcessDemographicsServiceImplTest {

    @Mock
    private DemographicsCorePort demographicsCorePort;

    @InjectMocks
    private ProcessDemographicsServiceImpl service;

    @Captor
    private ArgumentCaptor<DemographicsRequestDto> requestCaptor;

    @Test
    void executeShouldNormalizeRequestAndReturnCoreResponse() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("OperacionDemograficosCliente61")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer("true")
                        .age("7")
                        .familyDependents("2")
                        .build())
                .build();

        DemographicsResponseDto expected = DemographicsResponseDto.builder()
                .code("0")
                .message("OK")
                .build();

        when(demographicsCorePort.execute(org.mockito.ArgumentMatchers.any())).thenReturn(Mono.just(expected));

        DemographicsResponseDto response = service.execute(request).block();
        assertThat(response).isSameAs(expected);

        verify(demographicsCorePort).execute(requestCaptor.capture());
        DemographicsRequestDto normalized = requestCaptor.getValue();
        assertThat(normalized.getDemographicData().getCif()).isEqualTo("0000000000000123");
        assertThat(normalized.getDemographicData().getOperation()).isEqualTo("01");
        assertThat(normalized.getDemographicData().getNaturalCustomer()).isEqualTo("T");
        assertThat(normalized.getDemographicData().getAge()).isEqualTo("007");
        assertThat(normalized.getDemographicData().getFamilyDependents()).isEqualTo("002");
    }

    @Test
    void executeShouldReturnBusinessExceptionWhenRequestIsNull() {
                BusinessException businessException = assertThrows(BusinessException.class,
                                () -> service.execute(null).block());
                assertThat(businessException.getCode()).isEqualTo("1");
                assertThat(businessException.getMessage()).isEqualTo("Body input is required");
    }

    @Test
    void executeShouldReturnBusinessExceptionWhenOperationIsInvalid() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif("123456")
                        .operation("99")
                        .naturalCustomer("true")
                        .build())
                .build();

        BusinessException businessException = assertThrows(BusinessException.class,
                () -> service.execute(request).block());
        assertThat(businessException.getCode()).isEqualTo("4");
        assertThat(businessException.getMessage()).isEqualTo("Valor del campo operacion  inválido");
    }

    @Test
    void executeShouldNormalizeNaturalCustomerAsFalseWhenMissing() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("OperacionDemograficosCliente61")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer(null)
                        .build())
                .build();

        DemographicsResponseDto expected = DemographicsResponseDto.builder()
                .code("0")
                .message("OK")
                .build();

        when(demographicsCorePort.execute(org.mockito.ArgumentMatchers.any())).thenReturn(Mono.just(expected));

        DemographicsResponseDto response = service.execute(request).block();
        assertThat(response).isSameAs(expected);

        verify(demographicsCorePort).execute(requestCaptor.capture());
        DemographicsRequestDto normalized = requestCaptor.getValue();
        assertThat(normalized.getDemographicData().getNaturalCustomer()).isEqualTo("F");
    }

    @Test
    void executeShouldIgnoreDemographicDetailsWhenOperationIs02() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("OperacionDemograficosCliente61")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("02")
                        .naturalCustomer("true")
                        .countryOfBirth("EC")
                        .birthStateProvince("PICHINCHA")
                        .birthCity("QUITO")
                        .birthDate("19021976")
                        .age("7")
                        .gender("1")
                        .maritalStatus("1")
                        .profession("200")
                        .familyDependents("2")
                        .housingType("0")
                        .build())
                .build();

        DemographicsResponseDto expected = DemographicsResponseDto.builder()
                .code("0")
                .message("OK")
                .build();

        when(demographicsCorePort.execute(org.mockito.ArgumentMatchers.any())).thenReturn(Mono.just(expected));

        DemographicsResponseDto response = service.execute(request).block();
        assertThat(response).isSameAs(expected);

        verify(demographicsCorePort).execute(requestCaptor.capture());
        DemographicDataDto normalized = requestCaptor.getValue().getDemographicData();
        assertThat(normalized.getOperation()).isEqualTo("02");
        assertThat(normalized.getCountryOfBirth()).isNull();
        assertThat(normalized.getBirthStateProvince()).isNull();
        assertThat(normalized.getBirthCity()).isNull();
        assertThat(normalized.getBirthDate()).isNull();
        assertThat(normalized.getAge()).isNull();
        assertThat(normalized.getGender()).isNull();
        assertThat(normalized.getMaritalStatus()).isNull();
        assertThat(normalized.getProfession()).isNull();
        assertThat(normalized.getFamilyDependents()).isNull();
        assertThat(normalized.getHousingType()).isNull();
    }

    @Test
    void executeShouldReturn0282WhenCifExceedsMaximumLength() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif("99994545465455243256")
                        .operation("01")
                        .naturalCustomer("TRUE")
                        .build())
                .build();

        BusinessException businessException = assertThrows(BusinessException.class,
                () -> service.execute(request).block());

        assertThat(businessException.getCode()).isEqualTo("0282");
        assertThat(businessException.getMessage()).isEqualTo("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
        assertThat(businessException.getBackend()).isEqualTo(ApplicationBusinessConstants.BACKEND_BUSINESS);
        verifyNoInteractions(demographicsCorePort);
    }

    @Test
    void executeShouldReturnBusinessExceptionWhenCifIsBlank() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif(" ")
                        .operation("01")
                        .naturalCustomer("true")
                        .build())
                .build();

        BusinessException businessException = assertThrows(BusinessException.class,
                () -> service.execute(request).block());
        assertThat(businessException.getCode()).isEqualTo("1");
        assertThat(businessException.getMessage()).isEqualTo("Valor del campo cif vacío o inválido");
    }

    @Test
    void executeShouldReturnBusinessExceptionWhenNaturalCustomerIsBlank() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer(" ")
                        .build())
                .build();

        BusinessException businessException = assertThrows(BusinessException.class,
                () -> service.execute(request).block());
        assertThat(businessException.getCode()).isEqualTo("3");
        assertThat(businessException.getMessage()).isEqualTo("Valor del campo clienteNatural vacío o inválido");
    }

    @Test
    void executeShouldReturn9928ErrorWhenAgeIsNotNumeric() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer("TRUE")
                        .age("hola")
                        .build())
                .build();

        BusinessException businessException = assertThrows(BusinessException.class,
                () -> service.execute(request).block());

        assertThat(businessException.getCode()).isEqualTo("9928");
        assertThat(businessException.getMessage()).isEqualTo("Body no coincide con Tx061406Rq");
        assertThat(businessException.getType()).isEqualTo("ERROR");
        verifyNoInteractions(demographicsCorePort);
    }

    @Test
    void executeShouldReturn9928ErrorWhenFamilyDependentsIsNotNumeric() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer("TRUE")
                        .familyDependents("abc")
                        .build())
                .build();

        BusinessException businessException = assertThrows(BusinessException.class,
                () -> service.execute(request).block());

        assertThat(businessException.getCode()).isEqualTo("9928");
        assertThat(businessException.getMessage()).isEqualTo("Body no coincide con Tx061406Rq");
        assertThat(businessException.getType()).isEqualTo("ERROR");
        verifyNoInteractions(demographicsCorePort);
    }

    @Test
    void executeShouldSkipNumericValidationWhenOperationIs02() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("02")
                        .naturalCustomer("TRUE")
                        .age("hola")
                        .build())
                .build();

        DemographicsResponseDto expected = DemographicsResponseDto.builder().code("0").message("OK").build();
        when(demographicsCorePort.execute(org.mockito.ArgumentMatchers.any())).thenReturn(Mono.just(expected));

        DemographicsResponseDto response = service.execute(request).block();

        assertThat(response).isSameAs(expected);
        verify(demographicsCorePort).execute(org.mockito.ArgumentMatchers.any());
    }

    @Test
    void executeShouldReturnBusinessExceptionWhenNaturalCustomerIsInvalid() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .resourceId("resource")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer("XYZ")
                        .build())
                .build();

        BusinessException businessException = assertThrows(BusinessException.class,
                () -> service.execute(request).block());
        assertThat(businessException.getCode()).isEqualTo("3");
        assertThat(businessException.getMessage()).isEqualTo("Valor del campo clienteNatural vacío o inválido");
    }
}
