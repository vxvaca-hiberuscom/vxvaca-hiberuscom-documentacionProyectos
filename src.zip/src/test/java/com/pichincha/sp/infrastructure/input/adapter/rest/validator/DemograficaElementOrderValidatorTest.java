package com.pichincha.sp.infrastructure.input.adapter.rest.validator;

import com.pichincha.sp.domain.exception.SoapInputFaultException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DemograficaElementOrderValidatorTest {

    private final DemograficaElementOrderValidator validator = new DemograficaElementOrderValidator();

    @Test
    void shouldAcceptElementsInXsdOrder() {
        String soapXml = """
                <bodyIn>
                  <demografica>
                    <cif>0000000005783387</cif>
                    <operacion>01</operacion>
                    <clienteNatural>TRUE</clienteNatural>
                    <paisNacimiento>EC</paisNacimiento>
                  </demografica>
                </bodyIn>
                """;

        assertDoesNotThrow(() -> validator.validate(soapXml));
    }

    @Test
    void shouldRejectAlteredElementOrder() {
        String soapXml = """
                <bodyIn>
                  <demografica>
                    <cif>0000000005783387</cif>
                    <operacion>01</operacion>
                    <paisNacimiento>EC</paisNacimiento>
                    <clienteNatural>TRUE</clienteNatural>
                  </demografica>
                </bodyIn>
                """;

        assertThrows(SoapInputFaultException.class, () -> validator.validate(soapXml));
    }

    @Test
    void shouldRejectUnknownElement() {
        String soapXml = """
                <bodyIn>
                  <demografica>
                    <cif>0000000005783387</cif>
                    <cedula>01</cedula>
                  </demografica>
                </bodyIn>
                """;

        assertThrows(SoapInputFaultException.class, () -> validator.validate(soapXml));
    }

    @Test
    void shouldIgnoreWhenDemograficaBlockIsMissing() {
        assertDoesNotThrow(() -> validator.validate("<bodyIn></bodyIn>"));
    }
}
