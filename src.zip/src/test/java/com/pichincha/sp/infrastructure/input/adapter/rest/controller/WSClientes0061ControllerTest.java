package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.impl.SoapOperationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WSClientes0061ControllerTest {

    @Mock
    private SoapOperationService soapOperationService;

    @InjectMocks
    private WSClientes0061Controller controller;

    @Test
    void procesarOperacionShouldDelegateToSoapOperationService() {
        SoapEnvelopeRequest request = new SoapEnvelopeRequest();
        SoapEnvelopeResponse expectedResponse = new SoapEnvelopeResponse();

        when(soapOperationService.process(request)).thenReturn(Mono.just(expectedResponse));

        SoapEnvelopeResponse response = controller.procesarOperacion(request).block();

        assertThat(response).isSameAs(expectedResponse);
        verify(soapOperationService).process(request);
    }
}
