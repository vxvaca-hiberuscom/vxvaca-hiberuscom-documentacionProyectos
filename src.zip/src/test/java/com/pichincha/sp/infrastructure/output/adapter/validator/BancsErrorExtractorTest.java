package com.pichincha.sp.infrastructure.output.adapter.validator;

import com.pichincha.bnc.apiclient.dto.response.BancsError;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class BancsErrorExtractorTest {

    @Test
    void extractBusinessCodeShouldIgnoreHttpStatusCodes() {
        BancsError error = mock(BancsError.class);
        when(error.code()).thenReturn("500");
        when(error.message()).thenReturn("NO SE ENCONTRARON REGISTROS DEL CLIENTE");

        assertThat(BancsErrorExtractor.extractBusinessCode(error)).isEmpty();
        assertThat(BancsErrorExtractor.isHttpStatusCode("500")).isTrue();
    }

    @Test
    void extractBusinessCodeShouldFormatNumericBusinessCodes() {
        BancsError error = mock(BancsError.class);
        when(error.code()).thenReturn("282");

        assertThat(BancsErrorExtractor.extractBusinessCode(error)).isEqualTo("0282");
    }

    @Test
    void extractMessageShouldReadDescriptionWhenMessageIsBlank() {
        BancsError error = mock(BancsError.class);
        when(error.message()).thenReturn(null);

        assertThat(BancsErrorExtractor.extractMessage(error)).isEmpty();
    }
}
