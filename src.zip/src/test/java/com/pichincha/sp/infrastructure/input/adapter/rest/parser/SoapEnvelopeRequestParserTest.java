package com.pichincha.sp.infrastructure.input.adapter.rest.parser;

import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.infrastructure.input.adapter.rest.config.SoapXmlMapperConfig;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.validator.DemograficaElementOrderValidator;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SoapEnvelopeRequestParserTest {

    private final SoapEnvelopeRequestParser parser = new SoapEnvelopeRequestParser(
            SoapXmlMapperConfig.createSoapXmlMapper(),
            new DemograficaElementOrderValidator()
    );

    @Test
    void parseShouldReturnEnvelopeWhenXmlIsValid() {
        SoapEnvelopeRequest request = parser.parse(validSoapRequest());

        assertThat(request).isNotNull();
        assertThat(request.getBody()).isNotNull();
        assertThat(request.getBody().getOperacionDemograficosCliente51()).isNotNull();
        assertThat(request.getBody().getOperacionDemograficosCliente51().getBodyIn().getDemografica().getCif())
                .isEqualTo("0000000005783387");
    }

    @Test
    void parseShouldThrowSoapInputFaultWhenDemograficaOrderIsAltered() {
        String request = validSoapRequest()
                .replace("<clienteNatural>TRUE</clienteNatural>\n                          <paisNacimiento>EC</paisNacimiento>",
                        "<paisNacimiento>EC</paisNacimiento>\n                          <clienteNatural>TRUE</clienteNatural>");

        assertThrows(SoapInputFaultException.class, () -> parser.parse(request));
    }

    @Test
    void parseShouldThrowSoapInputFaultWhenXmlIsMalformed() {
        assertThrows(SoapInputFaultException.class, () -> parser.parse("<soapenv:Envelope>"));
    }

    private String validSoapRequest() {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:NS1="http://bpichincha.com/servicios">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51>
                      <headerIn>
                        <dispositivo>jmeter</dispositivo>
                        <empresa>0010</empresa>
                        <canal>02</canal>
                        <medio>020002</medio>
                        <aplicacion>00270</aplicacion>
                        <agencia>1</agencia>
                        <tipoTransaccion>202000101</tipoTransaccion>
                        <usuario>USINTERT</usuario>
                        <bancs>
                          <teller>90233</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cif>0000000005783387</cif>
                          <operacion>01</operacion>
                          <clienteNatural>TRUE</clienteNatural>
                          <paisNacimiento>EC</paisNacimiento>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """;
    }
}
