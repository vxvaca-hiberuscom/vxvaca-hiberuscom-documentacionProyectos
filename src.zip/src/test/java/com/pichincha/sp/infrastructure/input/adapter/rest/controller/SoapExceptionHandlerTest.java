package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.codec.DecodingException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ServerWebInputException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SoapExceptionHandlerTest {

    private static final String DEFAULT_SOAP_ERROR_MESSAGE = "Unexpected SOAP processing error";

    @Mock
    private SoapDemographicsMapper soapDemographicsMapper;

    @InjectMocks
    private SoapExceptionHandler soapExceptionHandler;

    @Test
    void handleBusinessExceptionShouldReturnSoapXmlResponse() {
        BusinessException exception = new BusinessException("400", "Business error", "resource", "component", "backend");
        SoapEnvelopeResponse expectedResponse = new SoapEnvelopeResponse();
        when(soapDemographicsMapper.toErrorSoapEnvelope(exception)).thenReturn(expectedResponse);

        ResponseEntity<SoapEnvelopeResponse> response = soapExceptionHandler.handleBusinessException(exception);

        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(response.getHeaders().getContentType()).isEqualTo(MediaType.TEXT_XML);
        assertThat(response.getBody()).isSameAs(expectedResponse);
        verify(soapDemographicsMapper).toErrorSoapEnvelope(exception);
    }

    @Test
    void handleSoapInputFaultShouldReturn500SoapFault() {
        ResponseEntity<String> response = soapExceptionHandler.handleSoapInputFault(
                new SoapInputFaultException("Missing mandatory field: cif"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getHeaders().getContentType()).isEqualTo(MediaType.TEXT_XML);
        assertThat(response.getBody()).contains("soapenv:Fault");
        assertThat(response.getBody()).contains("BIP3113E");
    }

    @Test
    void handleMalformedSoapEnvelopeShouldReturn500WithEnvelopeCreationMessage() {
        ResponseEntity<String> response = soapExceptionHandler.handleMalformedSoapEnvelope(
                new ServerWebInputException("Failed to read HTTP message"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).contains("soapenv:Fault");
        assertThat(response.getBody()).contains("Exception during creation of SOAP envelope");
    }

    @Test
    void handleSoapExceptionsShouldReturn500WhenCauseIsDecodingException() {
        DecodingException decodingException = new DecodingException("Invalid XML", new RuntimeException("XMLStreamException"));

        ResponseEntity<?> response = soapExceptionHandler.handleSoapExceptions(decodingException);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isInstanceOf(String.class);
        assertThat((String) response.getBody()).contains("Exception during creation of SOAP envelope");
    }

    @Test
    void handleSoapExceptionsShouldUseDefaultMessageWhenExceptionMessageIsNull() {
        SoapEnvelopeResponse expectedResponse = new SoapEnvelopeResponse();
        Exception exception = new Exception((String) null);
        when(soapDemographicsMapper.toErrorSoapEnvelope(DEFAULT_SOAP_ERROR_MESSAGE))
                .thenReturn(expectedResponse);

        ResponseEntity<?> response = soapExceptionHandler.handleSoapExceptions(exception);

        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(response.getHeaders().getContentType()).isEqualTo(MediaType.TEXT_XML);
        assertThat(response.getBody()).isInstanceOf(SoapEnvelopeResponse.class);
        assertThat((SoapEnvelopeResponse) response.getBody()).isSameAs(expectedResponse);
        verify(soapDemographicsMapper).toErrorSoapEnvelope(DEFAULT_SOAP_ERROR_MESSAGE);
    }
}
