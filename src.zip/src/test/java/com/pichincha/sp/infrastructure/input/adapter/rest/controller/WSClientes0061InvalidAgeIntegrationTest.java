package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.Application;
import com.pichincha.sp.application.port.output.DemographicsCorePort;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.BancsClientAdapter;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = Application.class,
        properties = {
                "optimus.web.filter.excluded-path-patterns.defaults=/actuator/**",
                "bancs.webclients.primary.base-url=http://localhost",
                "bancs.webclients.primary.max-in-memory-size=1MB",
                "bancs.webclients.primary.connector.max-connections=5"
        }
)
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class WSClientes0061InvalidAgeIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private DemographicsCorePort demographicsCorePort;

    @MockitoBean
    @SuppressWarnings("unused")
    private BancsClientAdapter bancsClientAdapter;

    @Test
    void shouldOmitInvalidAgeAndReturnSuccessWithoutCallingBancsWithInvalidField() {
        ArgumentCaptor<DemographicsRequestDto> requestCaptor = ArgumentCaptor.forClass(DemographicsRequestDto.class);

        when(demographicsCorePort.execute(any())).thenReturn(Mono.just(
                DemographicsResponseDto.builder()
                        .code("0")
                        .message("Ok")
                        .build()
        ));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithInvalidAge())
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    assertThat(body).contains("<codigo>0</codigo>");
                    assertThat(body).contains("<mensaje>Ok</mensaje>");
                    assertThat(body).doesNotContain("<codigo>9928</codigo>");
                    assertThat(body).doesNotContain("Existe un inconveniente");
                    assertThat(body).doesNotContain("Body no coincide con Tx061406Rq");
                });

        verify(demographicsCorePort).execute(requestCaptor.capture());
        assertThat(requestCaptor.getValue().getDemographicData().getAge()).isNull();
        assertThat(requestCaptor.getValue().getDemographicData().getFamilyDependents()).isNull();
    }

    private String soapRequestWithInvalidAge() {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:NS1="http://bpichincha.com/servicios">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51>
                      <headerIn>
                        <dispositivo>J1DAGfR+WlDPWBu3LngrmT09FOmSZ3kkpRmp2u9ZKwI</dispositivo>
                        <empresa>0010</empresa>
                        <canal>02</canal>
                        <medio>020002</medio>
                        <aplicacion>00647</aplicacion>
                        <agencia></agencia>
                        <tipoTransaccion>201006151</tipoTransaccion>
                        <geolocalizacion></geolocalizacion>
                        <usuario>USINTERT</usuario>
                        <unicidad></unicidad>
                        <guid>70fd9a960e4143979b56c4c303692f9b</guid>
                        <fechaHora>202506031158190365</fechaHora>
                        <filler></filler>
                        <idioma>es-EC</idioma>
                        <sesion>224bb1f4-4cda-4100-b5b7-510cccfe82e2</sesion>
                        <ip>20.42.33.36</ip>
                        <idCliente>1000227908</idCliente>
                        <tipoIdCliente>0001</tipoIdCliente>
                        <bancs>
                          <teller>90233</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cif>0000000005783387</cif>
                          <operacion>01</operacion>
                          <clienteNatural>TRUE</clienteNatural>
                          <edad>hola</edad>
                          <numeroCargasFamiliares>abc</numeroCargasFamiliares>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """;
    }
}
