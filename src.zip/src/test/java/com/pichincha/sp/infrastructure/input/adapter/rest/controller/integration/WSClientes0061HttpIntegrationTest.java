package com.pichincha.sp.infrastructure.input.adapter.rest.controller.integration;

import com.pichincha.sp.Application;
import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import com.pichincha.sp.infrastructure.output.adapter.BancsClientAdapter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = Application.class,
    properties = {
        "optimus.web.filter.excluded-path-patterns.defaults=/actuator/**",
        "bancs.webclients.primary.base-url=http://localhost",
        "bancs.webclients.primary.max-in-memory-size=1MB",
        "bancs.webclients.primary.connector.max-connections=5"
    }
)
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class WSClientes0061HttpIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private ProcessDemographicsPort processDemographicsPort;

    @MockitoBean
    private SoapDemographicsMapper soapDemographicsMapper;

    @MockitoBean
    @SuppressWarnings("unused")
    private BancsClientAdapter bancsClientAdapter;

    @BeforeEach
    void setup() {
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString())).thenReturn(new SoapEnvelopeResponse());
    }

    @Test
    void shouldValidateHttpStatus200OnKnownSoapEndpoint() {
        HttpStatus status = HttpStatus.valueOf(webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapEnvelope())
                .exchange()
                .expectStatus().isEqualTo(200)
            .expectHeader().contentTypeCompatibleWith(MediaType.TEXT_XML)
            .returnResult(String.class)
            .getStatus()
            .value());

        assertEquals(HttpStatus.OK, status);
    }

    @Test
    void shouldValidateHttpStatus404OnUnknownSoapEndpoint() {
        int statusCode = webTestClient.post()
                .uri("/IntegrationBus/soap/unknown-endpoint")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapEnvelope())
                .exchange()
            .expectStatus().isEqualTo(404)
            .returnResult(String.class)
            .getStatus()
            .value();

        assertEquals(404, statusCode);
    }

    @Test
    void shouldValidateHttpStatus500WhenUnhandledErrorOccurs() {
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString()))
                .thenThrow(new IllegalStateException("Forced error for HTTP 500 validation"));

        int statusCode = webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapEnvelope())
                .exchange()
            .expectStatus().isEqualTo(500)
            .returnResult(String.class)
            .getStatus()
            .value();

        assertEquals(500, statusCode);
    }

    private String minimalSoapEnvelope() {
        return """
                <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">
                    <soapenv:Header/>
                    <soapenv:Body/>
                </soapenv:Envelope>
                """;
    }
}