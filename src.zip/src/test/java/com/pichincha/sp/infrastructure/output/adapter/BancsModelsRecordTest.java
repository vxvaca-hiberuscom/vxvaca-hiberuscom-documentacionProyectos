package com.pichincha.sp.infrastructure.output.adapter;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class BancsModelsRecordTest {

    @Test
    void bancsDemographicsRequestShouldExposeRecordValues() {
        BancsDemographicsRequest request = BancsDemographicsRequest.builder()
                .customerCif("123")
                .operation("01")
                .naturalCustomer("T")
                .build();

        assertThat(request.customerCif()).isEqualTo("123");
        assertThat(request.operation()).isEqualTo("01");
        assertThat(request.naturalCustomer()).isEqualTo("T");
    }

    @Test
    void bancsDemographicsResponseShouldExposeRecordValues() {
        BancsDemographicsResponse response = BancsDemographicsResponse.builder()
                .countryOfBirth("EC")
                .coreErrorCode(0)
                .coreErrorDescription("OK")
                .build();

        assertThat(response.countryOfBirth()).isEqualTo("EC");
        assertThat(response.coreErrorCode()).isEqualTo(0);
        assertThat(response.coreErrorDescription()).isEqualTo("OK");
    }
}
