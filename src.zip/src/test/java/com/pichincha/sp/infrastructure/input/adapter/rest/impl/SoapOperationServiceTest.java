package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.generated.BodyInOperacionDemograficosCliente51;
import com.pichincha.sp.generated.Demografica;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.OperacionDemograficosCliente51;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapBodyRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SoapOperationServiceTest {

    private static final String DEFAULT_SOAP_BODY_NULL_MESSAGE = "SOAP body is null";
    private static final String DEFAULT_SOAP_OPERATION_NOT_FOUND_MESSAGE = "No valid SOAP operation found in Body";

    @Mock
    private ProcessDemographicsPort processDemographicsPort;

    @Mock
    private SoapDemographicsMapper soapDemographicsMapper;

    @InjectMocks
    private SoapOperationService soapOperationService;

    @Test
    void processShouldThrowSoapInputFaultWhenBodyIsNull() {
        assertThatThrownBy(() -> soapOperationService.process(new SoapEnvelopeRequest()).block())
                .isInstanceOf(SoapInputFaultException.class)
                .hasMessage(DEFAULT_SOAP_BODY_NULL_MESSAGE);

        verify(processDemographicsPort, never()).execute(any());
    }

    @Test
    void processShouldThrowSoapInputFaultWhenOperationIsMissing() {
        SoapEnvelopeRequest request = new SoapEnvelopeRequest();
        request.setBody(new SoapBodyRequest());

        assertThatThrownBy(() -> soapOperationService.process(request).block())
                .isInstanceOf(SoapInputFaultException.class)
                .hasMessage(DEFAULT_SOAP_OPERATION_NOT_FOUND_MESSAGE);

        verify(processDemographicsPort, never()).execute(any());
    }

    @Test
    void processShouldReturnSoapEnvelopeWhenServiceSucceeds() {
        SoapEnvelopeRequest request = buildValidRequest();
        OperacionDemograficosCliente51 operation = request.getBody().getOperacionDemograficosCliente51();
        GenericHeaderIn header = operation.getHeaderIn();

        DemographicsRequestDto domainRequest = DemographicsRequestDto.builder()
                .resourceId(InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION)
                .demographicData(DemographicDataDto.builder().cif("123").operation("01").naturalCustomer("T").build())
                .build();
        DemographicsResponseDto domainResponse = DemographicsResponseDto.builder().code("0").message("Ok").build();
        SoapEnvelopeResponse expectedResponse = new SoapEnvelopeResponse();

        when(soapDemographicsMapper.toDomain(operation)).thenReturn(domainRequest);
        when(processDemographicsPort.execute(domainRequest)).thenReturn(Mono.just(domainResponse));
        when(soapDemographicsMapper.toSoapEnvelopeResponse(domainResponse, header)).thenReturn(expectedResponse);

        SoapEnvelopeResponse response = soapOperationService.process(request).block();

        assertThat(response).isSameAs(expectedResponse);
        verify(soapDemographicsMapper).toDomain(operation);
        verify(processDemographicsPort).execute(domainRequest);
        verify(soapDemographicsMapper).toSoapEnvelopeResponse(domainResponse, header);
    }

    @Test
    void processShouldReturnErrorEnvelopeWhenServiceThrowsBusinessException() {
        SoapEnvelopeRequest request = buildValidRequest();
        OperacionDemograficosCliente51 operation = request.getBody().getOperacionDemograficosCliente51();
        GenericHeaderIn header = operation.getHeaderIn();

        DemographicsRequestDto domainRequest = DemographicsRequestDto.builder()
                .resourceId(InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION)
                .demographicData(DemographicDataDto.builder().cif("123").operation("01").naturalCustomer("T").build())
                .build();
        BusinessException businessException = new BusinessException("9929", "connector error", "FATAL", "resource", "component", "backend");
        SoapEnvelopeResponse expectedResponse = new SoapEnvelopeResponse();

        when(soapDemographicsMapper.toDomain(operation)).thenReturn(domainRequest);
        when(processDemographicsPort.execute(domainRequest)).thenReturn(Mono.error(businessException));
        when(soapDemographicsMapper.toErrorSoapEnvelope(businessException, header)).thenReturn(expectedResponse);

        SoapEnvelopeResponse response = soapOperationService.process(request).block();

        assertThat(response).isSameAs(expectedResponse);
        verify(soapDemographicsMapper).toErrorSoapEnvelope(businessException, header);
    }

    @Test
    void processShouldReturnFallbackEnvelopeWhenMapperThrowsBusinessException() {
        SoapEnvelopeRequest request = buildValidRequest();
        OperacionDemograficosCliente51 operation = request.getBody().getOperacionDemograficosCliente51();
        BusinessException businessException = new BusinessException("9927", "missing teller", "FATAL", "resource", "component", "backend");
        SoapEnvelopeResponse expectedResponse = new SoapEnvelopeResponse();

        when(soapDemographicsMapper.toDomain(operation)).thenThrow(businessException);
        when(soapDemographicsMapper.toErrorSoapEnvelope(businessException)).thenReturn(expectedResponse);

        SoapEnvelopeResponse response = soapOperationService.process(request).block();

        assertThat(response).isSameAs(expectedResponse);
        verify(soapDemographicsMapper).toErrorSoapEnvelope(businessException);
        verify(processDemographicsPort, never()).execute(any());
    }

    private SoapEnvelopeRequest buildValidRequest() {
        Demografica demografica = new Demografica();
        demografica.setCif("123");
        demografica.setOperacion("01");
        demografica.setClienteNatural("TRUE");

        BodyInOperacionDemograficosCliente51 bodyIn = new BodyInOperacionDemograficosCliente51();
        bodyIn.setDemografica(demografica);

        GenericHeaderIn headerIn = new GenericHeaderIn();

        OperacionDemograficosCliente51 operation = new OperacionDemograficosCliente51();
        operation.setHeaderIn(headerIn);
        operation.setBodyIn(bodyIn);

        SoapBodyRequest bodyRequest = new SoapBodyRequest();
        bodyRequest.setOperacionDemograficosCliente51(operation);

        SoapEnvelopeRequest request = new SoapEnvelopeRequest();
        request.setBody(bodyRequest);
        return request;
    }
}