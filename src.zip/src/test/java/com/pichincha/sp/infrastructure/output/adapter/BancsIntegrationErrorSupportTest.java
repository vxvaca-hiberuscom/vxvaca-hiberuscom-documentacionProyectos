package com.pichincha.sp.infrastructure.output.adapter;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class BancsIntegrationErrorSupportTest {

    @Test
    void shouldDetectCustomerDomainErrorFromIntegrationMessage() {
        String details = "BancsIntegrationException httpStatus=502, code=001, businessMessage=Error on: Value [99994545465455243256]";

        assertThat(BancsIntegrationErrorSupport.isCustomerDomainOrNotFoundError(details)).isTrue();
    }

    @Test
    void shouldNotDetectGenericConnectorErrors() {
        assertThat(BancsIntegrationErrorSupport.isCustomerDomainOrNotFoundError("connection reset")).isFalse();
    }

    @Test
    void shouldDetectRequestBodyValidationErrorFromIntegrationMessage() {
        String details = "BancsIntegrationException httpStatus=400, code=001, businessMessage=Body no coincide con Tx061406Rq";

        assertThat(BancsIntegrationErrorSupport.isRequestBodyValidationError(details)).isTrue();
    }

    @Test
    void shouldDetectRequestBodyValidationErrorFromExceptionMessageOnly() {
        String details = "400 Bad Request BancsIntegrationException httpStatus=400, code=001, businessMessage=Body no coincide con Tx061406Rq";

        assertThat(BancsIntegrationErrorSupport.isRequestBodyValidationError(details)).isTrue();
    }

    @Test
    void shouldNotDetectRequestBodyValidationErrorForOtherStatuses() {
        assertThat(BancsIntegrationErrorSupport.isRequestBodyValidationError("httpStatus=500 Body no coincide")).isFalse();
    }
}
