package com.pichincha.sp.infrastructure.output.adapter.mapper;

import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.infrastructure.output.adapter.BancsDemographicsRequest;
import org.mapstruct.factory.Mappers;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class BancsRequestMapperTest {

    private final BancsRequestMapper mapper = Mappers.getMapper(BancsRequestMapper.class);

    @Test
    void toBancsRequestShouldMapAllInputFields() {
        DemographicsRequestDto request = DemographicsRequestDto.builder()
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer("T")
                        .countryOfBirth("EC")
                        .birthStateProvince("PICHINCHA")
                        .birthCity("QUITO")
                        .birthDate("1990-01-01")
                        .age("034")
                        .gender("M")
                        .maritalStatus("S")
                        .propertySeparation("N")
                        .educationLevel("UNIVERSITY")
                        .profession("ENGINEER")
                        .familyDependents("002")
                        .housingType("OWN")
                        .legalDeedsAtAddress("Y")
                        .basicServicesAtAddress("Y")
                        .houseOwnerName("JOHN DOE")
                        .addressFeatures("URBAN")
                        .residenceTime("10")
                        .clientAddressSector("NORTH")
                        .build())
                .build();

        BancsDemographicsRequest mapped = mapper.toBancsRequest(request);

        assertThat(mapped.customerCif()).isEqualTo("123");
        assertThat(mapped.operation()).isEqualTo("01");
        assertThat(mapped.naturalCustomer()).isEqualTo("T");
        assertThat(mapped.countryOfBirth()).isEqualTo("EC");
        assertThat(mapped.birthStateProvince()).isEqualTo("PICHINCHA");
        assertThat(mapped.birthCity()).isEqualTo("QUITO");
        assertThat(mapped.birthDate()).isEqualTo("1990-01-01");
        assertThat(mapped.age()).isEqualTo("034");
        assertThat(mapped.gender()).isEqualTo("M");
        assertThat(mapped.maritalStatus()).isEqualTo("S");
        assertThat(mapped.propertySeparation()).isEqualTo("N");
        assertThat(mapped.educationLevel()).isEqualTo("UNIVERSITY");
        assertThat(mapped.profession()).isEqualTo("ENGINEER");
        assertThat(mapped.familyDependents()).isEqualTo("002");
        assertThat(mapped.housingType()).isEqualTo("OWN");
        assertThat(mapped.legalDeedsAtAddress()).isEqualTo("Y");
        assertThat(mapped.basicServicesAtAddress()).isEqualTo("Y");
        assertThat(mapped.houseOwnerName()).isEqualTo("JOHN DOE");
        assertThat(mapped.addressFeatures()).isEqualTo("URBAN");
        assertThat(mapped.residenceTime()).isEqualTo("10");
        assertThat(mapped.clientAddressSector()).isEqualTo("NORTH");
    }
}
