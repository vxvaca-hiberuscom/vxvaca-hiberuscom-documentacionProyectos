package com.pichincha.sp.infrastructure.output.adapter.mapper;

import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.output.adapter.BancsDemographicsResponse;
import org.mapstruct.factory.Mappers;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class BancsResponseMapperTest {

    private static final String DEFAULT_BANCS_RESPONSE_ERROR_MESSAGE = "Error processing BANCS response";

    private final BancsResponseMapper mapper = Mappers.getMapper(BancsResponseMapper.class);

    @Test
    void toDomainShouldMapSuccessfulResponse() {
        BancsDemographicsResponse response = BancsDemographicsResponse.builder()
                .countryOfBirth("EC")
                .birthStateProvince("PICHINCHA")
                .birthCity("QUITO")
            .birthDate("01011990")
                .age(34)
                .gender("M")
                .maritalStatus("S")
                .propertySeparation("N")
                .educationLevel("UNIVERSITY")
                .profession("ENGINEER")
                .familyDependents(2)
                .housingType("OWN")
                .legalDeedsAtAddress("Y")
                .basicServicesAtAddress("Y")
                .houseOwnerName("JOHN DOE")
                .addressFeatures("URBAN")
                .residenceTime("10")
                .clientAddressSector("NORTH")
                .build();

        DemographicsResponseDto result = mapper.toDomain(response);

        assertThat(result.getCode()).isEqualTo(InfrastructureBusinessConstants.SUCCESS_CODE);
        assertThat(result.getMessage()).isEqualTo(InfrastructureBusinessConstants.SUCCESS_MESSAGE);
        assertThat(result.getDemographicData().getCountryOfBirth()).isEqualTo("EC");
        assertThat(result.getDemographicData().getBirthDate()).isEqualTo("01/01/1990");
        assertThat(result.getDemographicData().getAge()).isEqualTo("34");
        assertThat(result.getDemographicData().getFamilyDependents()).isEqualTo("2");
    }

    @Test
    void toDomainShouldKeepNullableNumericFieldsAsNull() {
        BancsDemographicsResponse response = BancsDemographicsResponse.builder()
                .age(null)
                .familyDependents(null)
                .build();

        DemographicsResponseDto result = mapper.toDomain(response);

        assertThat(result.getDemographicData().getAge()).isNull();
        assertThat(result.getDemographicData().getFamilyDependents()).isNull();
    }

    @Test
    void toDomainShouldThrowBusinessExceptionWhenCoreErrorCodeIs282() {
        BancsDemographicsResponse response = BancsDemographicsResponse.builder()
                .coreErrorCode(282)
                .coreErrorDescription("NO SE ENCONTRARON REGISTROS DEL CLIENTE")
                .build();

        BusinessException exception = assertThrows(BusinessException.class, () -> mapper.toDomain(response));

        assertThat(exception.getCode()).isEqualTo("0282");
        assertThat(exception.getMessage()).isEqualTo("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
        assertThat(exception.getType()).isEqualTo("ERROR");
        assertThat(exception.getBackend()).isEqualTo("00045");
        assertThat(exception.getComponent()).isEqualTo(InfrastructureBusinessConstants.COMPONENT_BANCS_TX);
    }

    @Test
    void toDomainShouldThrowBusinessExceptionWithDefaultMessageWhenCoreErrorDescriptionIsBlank() {
        BancsDemographicsResponse response = BancsDemographicsResponse.builder()
                .coreErrorCode(500)
                .coreErrorDescription("   ")
                .build();

        BusinessException exception = assertThrows(BusinessException.class, () -> mapper.toDomain(response));

        assertThat(exception.getCode()).isEqualTo("0500");
        assertThat(exception.getMessage()).isEqualTo(DEFAULT_BANCS_RESPONSE_ERROR_MESSAGE);
        assertThat(exception.getResource()).isEqualTo(InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION);
        assertThat(exception.getComponent()).isEqualTo(InfrastructureBusinessConstants.COMPONENT_BANCS_TX);
        assertThat(exception.getBackend()).isEqualTo("00045");
    }

    @Test
    void toDomainShouldUseCustomerNotFoundMessageWhenCoreErrorCodeIs282WithoutDescription() {
        BancsDemographicsResponse response = BancsDemographicsResponse.builder()
                .coreErrorCode(282)
                .coreErrorDescription("   ")
                .build();

        BusinessException exception = assertThrows(BusinessException.class, () -> mapper.toDomain(response));

        assertThat(exception.getCode()).isEqualTo("0282");
        assertThat(exception.getMessage()).isEqualTo("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
    }
}
