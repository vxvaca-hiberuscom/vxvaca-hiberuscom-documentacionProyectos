package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.generated.BancsTeller;
import com.pichincha.sp.generated.BodyInOperacionDemograficosCliente51;
import com.pichincha.sp.generated.Demografica;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.OperacionDemograficosCliente51;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SoapDemographicsMapperTest {

    private final SoapDemographicsMapper mapper = new SoapDemographicsMapper();

    @Test
    void toErrorSoapEnvelopeShouldApplyDefaultValuesWhenInputMessageIsNull() {
        SoapEnvelopeResponse response = mapper.toErrorSoapEnvelope((String) null);

        assertThat(response).isNotNull();
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getOperacionDemograficosCliente51Response()).isNotNull();
        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getCodigo())
                .isEqualTo("999");
        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getMensaje())
                .isEqualTo("Unexpected SOAP processing error");
        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getTipo())
                .isEqualTo("ERROR");
    }

    @Test
    void toErrorSoapEnvelopeShouldMapBusinessExceptionValues() {
        BusinessException exception = new BusinessException("123", "controlled", "resource-x", "component-x", "backend-x");

        SoapEnvelopeResponse response = mapper.toErrorSoapEnvelope(exception);

        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getCodigo()).isEqualTo("123");
        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getMensaje()).isEqualTo("controlled");
        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getRecurso())
                .isEqualTo(InfrastructureBusinessConstants.SOAP_RESOURCE_DEMOGRAPHICS_OPERATION);
        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getComponente())
                .isEqualTo(InfrastructureBusinessConstants.SOAP_COMPONENT_WSCLIENTES);
        assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getBackend()).isEqualTo("backend-x");
    }

        @Test
        void toErrorSoapEnvelopeShouldRemoveBusinessPrefixFromMessage() {
                BusinessException exception = new BusinessException(
                                "0282",
                                "TCSBRKR1_BP-NO SE ENCONTRARON REGISTROS DEL CLIENTE",
                                "ERROR",
                                "resource-x",
                                "component-x",
                                "backend-x"
                );

                SoapEnvelopeResponse response = mapper.toErrorSoapEnvelope(exception);

                assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getMensaje())
                                .isEqualTo("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
        }

        @Test
        void toErrorSoapEnvelopeShouldKeepMensajeNegocioEmptyForErrorType() {
                BusinessException exception = new BusinessException(
                                "9928",
                                "Body no coincide con Tx061406Rq",
                                "ERROR",
                                "resource-x",
                                "component-x",
                                "backend-x"
                );

                SoapEnvelopeResponse response = mapper.toErrorSoapEnvelope(exception);

                assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getTipo())
                                .isEqualTo("ERROR");
                assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getMensajeNegocio())
                                .isEmpty();
        }

        @Test
        void toErrorSoapEnvelopeShouldPopulateMensajeNegocioForFatalType() {
                BusinessException exception = new BusinessException(
                                "9928",
                                "ESB-%2% Forced connector exception",
                                "FATAL",
                                "resource-x",
                                "component-x",
                                "backend-x"
                );

                SoapEnvelopeResponse response = mapper.toErrorSoapEnvelope(exception);

                assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getTipo())
                                .isEqualTo("FATAL");
                assertThat(response.getBody().getOperacionDemograficosCliente51Response().getError().getMensajeNegocio())
                                .isEqualTo("Existe un inconveniente para ejecutar tu transacción. Por favor intenta más tarde.");
        }

    @Test
    void toDomainShouldMapRequestAndBancsUserData() {
        OperacionDemograficosCliente51 request = buildOperation("0001", "", "", "HEADER-CH", "HEADER-APP");

        DemographicsRequestDto domain = mapper.toDomain(request);

        assertThat(domain.getResourceId()).isEqualTo(InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION);
        assertThat(domain.getBancsUser().getTeller()).isEqualTo("0001");
        assertThat(domain.getBancsUser().getChannel()).isEqualTo("HEADER-CH");
        assertThat(domain.getBancsUser().getApplication()).isEqualTo("HEADER-APP");
        assertThat(domain.getDemographicData().getCif()).isEqualTo("123");
        assertThat(domain.getDemographicData().getOperation()).isEqualTo("01");
        assertThat(domain.getDemographicData().getNaturalCustomer()).isEqualTo("TRUE");
    }

    @Test
    void toDomainShouldThrowSoapInputFaultWhenCifTagIsMissing() {
        OperacionDemograficosCliente51 request = buildOperation("0001", "", "", "HEADER-CH", "HEADER-APP");
        request.getBodyIn().getDemografica().setCif(null);

        assertThrows(SoapInputFaultException.class, () -> mapper.toDomain(request));
    }

    @Test
    void toDomainShouldThrowSoapInputFaultWhenOperacionTagIsMissing() {
        OperacionDemograficosCliente51 request = buildOperation("0001", "", "", "HEADER-CH", "HEADER-APP");
        request.getBodyIn().getDemografica().setOperacion(null);

        assertThrows(SoapInputFaultException.class, () -> mapper.toDomain(request));
    }

    @Test
    void toDomainShouldThrowSoapInputFaultWhenDemograficaIsMissing() {
        OperacionDemograficosCliente51 request = buildOperation("0001", "", "", "HEADER-CH", "HEADER-APP");
        request.getBodyIn().setDemografica(null);

        assertThrows(SoapInputFaultException.class, () -> mapper.toDomain(request));
    }

    @Test
    void toDomainShouldThrowSoapInputFaultWhenClienteNaturalTagIsMissing() {
        OperacionDemograficosCliente51 request = buildOperation("0001", "", "", "HEADER-CH", "HEADER-APP");
        request.getBodyIn().getDemografica().setClienteNatural(null);

        assertThrows(SoapInputFaultException.class, () -> mapper.toDomain(request));
    }

    @Test
    void toDomainShouldThrowBusinessExceptionWhenTellerIsMissing() {
        OperacionDemograficosCliente51 request = buildOperation("", "", "", "HEADER-CH", "HEADER-APP");

        BusinessException exception = assertThrows(BusinessException.class, () -> mapper.toDomain(request));

        assertThat(exception.getCode()).isEqualTo("9927");
                assertThat(exception.getType()).isEqualTo("ERROR");
                assertThat(exception.getBackend()).isEqualTo("00045");
    }

    @Test
    void toSoapEnvelopeResponseShouldMapSuccessPayloadAndHeader() {
        GenericHeaderIn requestHeader = new GenericHeaderIn();
        requestHeader.setAplicacion("APP");
        requestHeader.setCanal("CH");
        requestHeader.setGuid("guid-1");

        DemographicsResponseDto response = DemographicsResponseDto.builder()
                .code("0")
                .message("OK")
                .demographicData(DemographicDataDto.builder()
                        .countryOfBirth("EC")
                        .birthCity("QUITO")
                        .build())
                .build();

        SoapEnvelopeResponse envelope = mapper.toSoapEnvelopeResponse(response, requestHeader);

        assertThat(envelope.getBody()).isNotNull();
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getError().getCodigo()).isEqualTo("0");
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getError().getTipo()).isEqualTo("INFO");
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getError().getRecurso())
                .isEqualTo(InfrastructureBusinessConstants.SOAP_RESOURCE_DEMOGRAPHICS_OPERATION);
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getError().getComponente())
                .isEqualTo(InfrastructureBusinessConstants.SOAP_COMPONENT_WSCLIENTES);
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getBodyOut().getDemografica().getPaisNacimiento()).isEqualTo("EC");
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getHeaderOut().getAplicacion()).isEqualTo("APP");
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getHeaderOut().getDocumento().getJournals()
                .getJournal()).hasSize(1);
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getHeaderOut().getDocumento().getJournals()
                .getJournal().getFirst().getValor()).isEmpty();
    }

    @Test
    void toErrorSoapEnvelopeWithHeaderShouldNormalizeBlankValues() {
        GenericHeaderIn requestHeader = new GenericHeaderIn();
        requestHeader.setCanal("CH");
        requestHeader.setAplicacion("APP");

        BusinessException exception = new BusinessException("", "", "", "", "", "");

        SoapEnvelopeResponse envelope = mapper.toErrorSoapEnvelope(exception, requestHeader);

        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getError().getCodigo())
                .isEqualTo("999");
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getError().getRecurso())
                .isEqualTo(InfrastructureBusinessConstants.SOAP_RESOURCE_DEMOGRAPHICS_OPERATION);
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getError().getComponente())
                .isEqualTo(InfrastructureBusinessConstants.SOAP_COMPONENT_WSCLIENTES);
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getHeaderOut().getCanal())
                .isEqualTo("CH");
        assertThat(envelope.getBody().getOperacionDemograficosCliente51Response().getHeaderOut().getDocumento().getJournals()
                .getJournal()).hasSize(1);
    }

    private OperacionDemograficosCliente51 buildOperation(String teller, String bancsCanal, String bancsApplication,
                                                           String headerCanal, String headerApplication) {
        Demografica demografica = new Demografica();
        demografica.setCif("123");
        demografica.setOperacion("01");
        demografica.setClienteNatural("TRUE");

        BodyInOperacionDemograficosCliente51 bodyIn = new BodyInOperacionDemograficosCliente51();
        bodyIn.setDemografica(demografica);

        BancsTeller bancsTeller = new BancsTeller();
        bancsTeller.setTeller(teller);
        bancsTeller.setCanal(bancsCanal);
        bancsTeller.setAplicacion(bancsApplication);
        bancsTeller.setTerminal("001");
        bancsTeller.setInstitucion("003");
        bancsTeller.setAgencia("001");
        bancsTeller.setEstacion("001");

        GenericHeaderIn headerIn = new GenericHeaderIn();
        headerIn.setCanal(headerCanal);
        headerIn.setAplicacion(headerApplication);
        headerIn.setBancs(bancsTeller);

        OperacionDemograficosCliente51 request = new OperacionDemograficosCliente51();
        request.setHeaderIn(headerIn);
        request.setBodyIn(bodyIn);
        return request;
    }
}
