package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapBodyResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapHeaderResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.impl.SoapOperationService;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import com.pichincha.sp.infrastructure.input.adapter.rest.parser.SoapEnvelopeRequestParser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@WebFluxTest(controllers = WSClientes0061Controller.class)
@AutoConfigureWebTestClient
@Import({SoapExceptionHandler.class, SoapOperationService.class})
@ActiveProfiles("test")
class WSClientes0061WebFluxIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private ProcessDemographicsPort processDemographicsPort;

    @MockitoBean
    private SoapDemographicsMapper soapDemographicsMapper;

    @MockitoBean
    private SoapEnvelopeRequestParser soapEnvelopeRequestParser;

    @BeforeEach
    void setup() {
        when(soapEnvelopeRequestParser.parse(anyString())).thenReturn(new SoapEnvelopeRequest());
        when(processDemographicsPort.execute(any())).thenReturn(Mono.just(new com.pichincha.sp.domain.dto.DemographicsResponseDto()));
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString())).thenReturn(buildMinimalEnvelope());
        when(soapDemographicsMapper.toSoapEnvelopeResponse(any(), any())).thenReturn(buildMinimalEnvelope());
        when(soapDemographicsMapper.toDomain(any())).thenReturn(
            com.pichincha.sp.domain.dto.DemographicsRequestDto.builder()
                .resourceId("test")
                .demographicData(com.pichincha.sp.domain.dto.DemographicDataDto.builder()
                    .cif("0001")
                    .operation("01")
                    .build())
                .build()
        );
    }

    private SoapEnvelopeResponse buildMinimalEnvelope() {
        SoapEnvelopeResponse response = new SoapEnvelopeResponse();
        response.setHeader(new SoapHeaderResponse());
        response.setBody(new SoapBodyResponse());
        return response;
    }

    @Test
    void shouldValidateHttpStatus200OnValidSoapPath() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapRequest())
                .exchange()
                .expectStatus().isEqualTo(200);
    }

    @Test
    void shouldValidateHttpStatus404OnUnknownPath() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/unknown-path")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapRequest())
                .exchange()
                .expectStatus().isEqualTo(404);
    }

    @Test
    void shouldValidateHttpStatus500OnUnhandledError() {
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString()))
                .thenThrow(new IllegalStateException("Forced error for HTTP 500"));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapRequest())
                .exchange()
                .expectStatus().isEqualTo(500);
    }

    private String minimalSoapRequest() {
        return """
                <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">
                    <soapenv:Header/>
                    <soapenv:Body/>
                </soapenv:Envelope>
                """;
    }
}
