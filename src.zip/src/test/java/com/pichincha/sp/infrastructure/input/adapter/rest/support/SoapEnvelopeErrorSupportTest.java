package com.pichincha.sp.infrastructure.input.adapter.rest.support;

import org.junit.jupiter.api.Test;
import org.springframework.core.codec.DecodingException;

import static org.assertj.core.api.Assertions.assertThat;

class SoapEnvelopeErrorSupportTest {

    @Test
    void shouldDetectDecodingExceptionAsEnvelopeParsingError() {
        DecodingException exception = new DecodingException("Invalid XML", new RuntimeException("javax.xml.stream.XMLStreamException"));

        assertThat(SoapEnvelopeErrorSupport.isEnvelopeParsingError(exception)).isTrue();
    }

    @Test
    void shouldIgnoreUnrelatedExceptions() {
        assertThat(SoapEnvelopeErrorSupport.isEnvelopeParsingError(new IllegalStateException("other"))).isFalse();
    }
}
