package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.Application;
import com.pichincha.sp.application.constants.ApplicationBusinessConstants;
import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.output.adapter.BancsClientAdapter;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = Application.class,
        properties = {
                "optimus.web.filter.excluded-path-patterns.defaults=/actuator/**",
                "bancs.webclients.primary.base-url=http://localhost",
                "bancs.webclients.primary.max-in-memory-size=1MB",
                "bancs.webclients.primary.connector.max-connections=5"
        }
)
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class WSClientes0061ErrorContractIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private ProcessDemographicsPort processDemographicsPort;

        @MockitoBean
        @SuppressWarnings("unused")
        private BancsClientAdapter bancsClientAdapter;

    @Test
    void shouldReturn9927WhenTellerIsMissingInRequestHeader() {
        String request = soapRequestWithTeller("");

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(request)
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>9927</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("Datos de la cabecera de la transaccion no se han asignado");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>ERROR</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00045</backend>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("Existe un inconveniente");
                });
    }

    @Test
    void shouldReturn500SoapFaultWhenXmlIsMalformed() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue("c<invalid xml")
                .exchange()
                .expectStatus().isEqualTo(500)
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("soapenv:Fault");
                    org.assertj.core.api.Assertions.assertThat(body).contains("Exception during creation of SOAP envelope");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("<codigo>999</codigo>");
                });
    }

    @Test
    void shouldReturn500SoapFaultWhenEnvelopeNamespaceIsIncorrect() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithWrongEnvelopeNamespace())
                .exchange()
                .expectStatus().isEqualTo(500)
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("soapenv:Fault");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("<codigo>999</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("Existe un inconveniente");
                });
    }

    @Test
    void shouldReturn500SoapFaultWhenCifTagIsRenamed() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithCedulaInsteadOfCif())
                .exchange()
                .expectStatus().isEqualTo(500)
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("soapenv:Fault");
                    org.assertj.core.api.Assertions.assertThat(body).contains("BIP3113E");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("<codigo>0282</codigo>");
                });
    }

    @Test
    void shouldReturn500SoapFaultWhenOperacionTagIsRenamed() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithRenamedOperacionTag())
                .exchange()
                .expectStatus().isEqualTo(500)
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("soapenv:Fault");
                    org.assertj.core.api.Assertions.assertThat(body).contains("BIP3113E");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("<codigo>4</codigo>");
                });
    }

    @Test
    void shouldReturn0282WhenCifIsOutsideDomain() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.error(
                new BusinessException(
                        "0282",
                        "NO SE ENCONTRARON REGISTROS DEL CLIENTE",
                        "ERROR",
                        InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                        ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                        ApplicationBusinessConstants.BACKEND_BUSINESS
                )));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithCif("99994545465455243256"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>0282</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>ERROR</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00045</backend>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("<codigo>9928</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("Existe un inconveniente");
                });
    }

    @Test
    void shouldReturn0282WhenCustomerIsNotRegisteredInBancs() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.error(
                new BusinessException(
                        "0282",
                        "NO SE ENCONTRARON REGISTROS DEL CLIENTE",
                        "ERROR",
                        InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                        InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                        "00045"
                )));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithTeller("90233"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>0282</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>ERROR</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00045</backend>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("Existe un inconveniente");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("<codigo>9929</codigo>");
                });
    }

    @Test
    void shouldReturn9928WhenConnectorThrowsUnhandledException() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.error(
                new BusinessException(
                        "9928",
                        "ESB-%2% Forced connector exception",
                        "FATAL",
                        InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                        InfrastructureBusinessConstants.COMPONENT_BANCS_ADAPTER,
                        "00638"
                )));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithTeller("1"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>9928</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("ESB-%2% Forced connector exception");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>FATAL</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00638</backend>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<mensajeNegocio></mensajeNegocio>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("Existe un inconveniente");
                });
    }

    @Test
    void shouldReturn9928ErrorWhenRequestBodyDoesNotMatchBancsTransaction() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.error(
                new BusinessException(
                        "9928",
                        "ESB-%2% BancsIntegrationException httpStatus=400, code=001, businessMessage=Body no coincide con Tx061406Rq",
                        "ERROR",
                        InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                        InfrastructureBusinessConstants.COMPONENT_BANCS_ADAPTER,
                        "00638"
                )));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithTeller("1"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>9928</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("Body no coincide con Tx061406Rq");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>ERROR</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00638</backend>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<mensajeNegocio></mensajeNegocio>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("Existe un inconveniente");
                });
    }

    @Test
    void shouldReturn9929FatalWhenBancsResponds503() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.error(
                new BusinessException(
                        "9929",
                        "Error al invocar transaccion Bancs",
                        "FATAL",
                        InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                        InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                        "00045"
                )));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithTeller("1"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>9929</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("Error al invocar transaccion Bancs");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>FATAL</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00045</backend>");
                });
    }

    @Test
    void shouldReturn9929ErrorWhenBancsRespondsNon503BusinessError() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.error(
                new BusinessException(
                        "9929",
                        "Error al invocar transaccion Bancs",
                        "ERROR",
                        InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                        InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                        "00045"
                )));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithTeller("1"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>9929</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("Error al invocar transaccion Bancs");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>ERROR</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00045</backend>");
                });
    }

    @Test
    void shouldReturn9920WhenBancsTimeoutOccurs() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.error(
                new BusinessException(
                        "9920",
                        "Tiempo de espera terminado sin respuesta",
                        "FATAL",
                        InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                        InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                        "00638"
                )));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithTeller("1"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>9920</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("Tiempo de espera terminado sin respuesta");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>FATAL</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00638</backend>");
                });
    }

    @Test
    void shouldReturnOkWhenServiceRespondsSuccess() {
        when(processDemographicsPort.execute(any())).thenReturn(Mono.just(
                DemographicsResponseDto.builder()
                        .code("0")
                        .message("Ok")
                        .build()
        ));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithTeller("1"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>0</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<mensaje>Ok</mensaje>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>INFO</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<backend>00638</backend>");
                });
    }

    private String soapRequestWithTeller(String teller) {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:NS1="http://bpichincha.com/servicios">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51>
                      <headerIn>
                        <dispositivo>J1DAGfR+WlDPWBu3LngrmT09FOmSZ3kkpRmp2u9ZKwI</dispositivo>
                        <empresa>0010</empresa>
                        <canal>02</canal>
                        <medio>020002</medio>
                        <aplicacion>00647</aplicacion>
                        <agencia></agencia>
                        <tipoTransaccion>201006151</tipoTransaccion>
                        <geolocalizacion></geolocalizacion>
                        <usuario>USINTERT</usuario>
                        <unicidad></unicidad>
                        <guid>70fd9a960e4143979b56c4c303692f9b</guid>
                        <fechaHora>202506031158190365</fechaHora>
                        <filler></filler>
                        <idioma>es-EC</idioma>
                        <sesion>224bb1f4-4cda-4100-b5b7-510cccfe82e2</sesion>
                        <ip>20.42.33.36</ip>
                        <idCliente>1000227908</idCliente>
                        <tipoIdCliente>0001</tipoIdCliente>
                        <bancs>
                          <teller>%s</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cif>0000000005783387</cif>
                          <operacion>01</operacion>
                          <clienteNatural>TRUE</clienteNatural>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """.formatted(teller);
    }

    private String soapRequestWithCif(String cif) {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:NS1="http://bpichincha.com/servicios">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51>
                      <headerIn>
                        <dispositivo>jmeter</dispositivo>
                        <empresa>0010</empresa>
                        <canal>02</canal>
                        <medio>020002</medio>
                        <aplicacion>00270</aplicacion>
                        <agencia>1</agencia>
                        <tipoTransaccion>202000101</tipoTransaccion>
                        <geolocalizacion></geolocalizacion>
                        <usuario>USINTERT</usuario>
                        <unicidad>sdfgsfdgfd67fdsgfdsgfdsgfdsgfdgfdsgfdsgfds</unicidad>
                        <guid>sdafdsafasdfadsfdvdsvdfsvfdsv</guid>
                        <fechaHora>20180517184120</fechaHora>
                        <filler></filler>
                        <idioma>es-EC</idioma>
                        <sesion>b56a9824c9dd4dd79997e44490975yy4</sesion>
                        <ip>10.0.94.104</ip>
                        <idCliente>0602370777</idCliente>
                        <tipoIdCliente>0001</tipoIdCliente>
                        <bancs>
                          <teller>90233</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cif>%s</cif>
                          <operacion>01</operacion>
                          <clienteNatural>TRUE</clienteNatural>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """.formatted(cif);
    }

    private String soapRequestWithWrongEnvelopeNamespace() {
        return """
                <soapenv:Envelope xmlns:soapenv="http://wrong.namespace/">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51 xmlns:NS1="http://bpichincha.com/servicios">
                      <headerIn>
                        <bancs>
                          <teller>1</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cif>0000000005783387</cif>
                          <operacion>01</operacion>
                          <clienteNatural>TRUE</clienteNatural>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """;
    }

    private String soapRequestWithCedulaInsteadOfCif() {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:NS1="http://bpichincha.com/servicios">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51>
                      <headerIn>
                        <dispositivo>J1DAGfR+WlDPWBu3LngrmT09FOmSZ3kkpRmp2u9ZKwI</dispositivo>
                        <empresa>0010</empresa>
                        <canal>02</canal>
                        <medio>020002</medio>
                        <aplicacion>00647</aplicacion>
                        <agencia></agencia>
                        <tipoTransaccion>201006151</tipoTransaccion>
                        <geolocalizacion></geolocalizacion>
                        <usuario>USINTERT</usuario>
                        <unicidad></unicidad>
                        <guid>70fd9a960e4143979b56c4c303692f9b</guid>
                        <fechaHora>202506031158190365</fechaHora>
                        <filler></filler>
                        <idioma>es-EC</idioma>
                        <sesion>224bb1f4-4cda-4100-b5b7-510cccfe82e2</sesion>
                        <ip>20.42.33.36</ip>
                        <idCliente>1000227908</idCliente>
                        <tipoIdCliente>0001</tipoIdCliente>
                        <bancs>
                          <teller>1</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cedula>0000000005783387</cedula>
                          <operacion>01</operacion>
                          <clienteNatural>TRUE</clienteNatural>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """;
    }

    private String soapRequestWithRenamedOperacionTag() {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:NS1="http://bpichincha.com/servicios">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51>
                      <headerIn>
                        <dispositivo>J1DAGfR+WlDPWBu3LngrmT09FOmSZ3kkpRmp2u9ZKwI</dispositivo>
                        <empresa>0010</empresa>
                        <canal>02</canal>
                        <medio>020002</medio>
                        <aplicacion>00647</aplicacion>
                        <agencia></agencia>
                        <tipoTransaccion>201006151</tipoTransaccion>
                        <geolocalizacion></geolocalizacion>
                        <usuario>USINTERT</usuario>
                        <unicidad></unicidad>
                        <guid>70fd9a960e4143979b56c4c303692f9b</guid>
                        <fechaHora>202506031158190365</fechaHora>
                        <filler></filler>
                        <idioma>es-EC</idioma>
                        <sesion>224bb1f4-4cda-4100-b5b7-510cccfe82e2</sesion>
                        <ip>20.42.33.36</ip>
                        <idCliente>1000227908</idCliente>
                        <tipoIdCliente>0001</tipoIdCliente>
                        <bancs>
                          <teller>1</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cif>0000000005783387</cif>
                          <tipoOperacion>01</tipoOperacion>
                          <clienteNatural>TRUE</clienteNatural>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """;
    }
}
