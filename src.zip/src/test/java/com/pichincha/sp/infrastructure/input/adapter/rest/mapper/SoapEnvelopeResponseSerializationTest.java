package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.infrastructure.input.adapter.rest.config.SoapXmlMapperConfig;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class SoapEnvelopeResponseSerializationTest {

    private final SoapDemographicsMapper mapper = new SoapDemographicsMapper();
    private final XmlMapper xmlMapper = SoapXmlMapperConfig.createSoapXmlMapper();

    @Test
    void successResponseShouldSerializeJournalStructure() throws Exception {
        GenericHeaderIn requestHeader = new GenericHeaderIn();
        requestHeader.setDispositivo("jmeter");
        requestHeader.setEmpresa("0010");

        DemographicsResponseDto response = DemographicsResponseDto.builder()
                .code("0")
                .message("Ok")
                .demographicData(DemographicDataDto.builder()
                        .countryOfBirth("EC")
                        .build())
                .build();

        SoapEnvelopeResponse envelope = mapper.toSoapEnvelopeResponse(response, requestHeader);
        String xml = xmlMapper.writeValueAsString(envelope);

        assertThat(xml).contains("<journals>");
        assertThat(xml).contains("<journal>");
        assertThat(xml).contains("<valor");
        assertThat(xml).doesNotContain("<journals/>");
    }
}
