package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.sp.domain.dto.BancsUserDataDto;
import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.output.adapter.mapper.BancsRequestMapper;
import com.pichincha.sp.infrastructure.output.adapter.mapper.BancsResponseMapper;
import com.pichincha.sp.infrastructure.output.adapter.validator.BancsResponseValidator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BancsDemographicsAdapterTest {

    @Mock
    private BancsClientPort bancsClientPort;

    @Mock
    private BancsResponseValidator responseValidator;

    @Mock
    private BancsRequestMapper requestMapper;

    @Mock
    private BancsResponseMapper responseMapper;

    @InjectMocks
    private BancsDemographicsAdapter adapter;

        @Captor
        private ArgumentCaptor<BancsRequest<BancsDemographicsRequest>> bancsRequestCaptor;

    @Test
    void executeShouldReturnMappedResponseWhenBancsCallIsSuccessful() {
        DemographicsRequestDto request = buildRequestWithUser();
        BancsDemographicsRequest bancsBody = BancsDemographicsRequest.builder().customerCif("123").build();
        BancsDemographicsResponse validatedBody = BancsDemographicsResponse.builder().countryOfBirth("EC").build();
        DemographicsResponseDto expected = DemographicsResponseDto.builder().code("0").message("OK").build();
        BancsResponse<BancsDemographicsResponse> bancsResponse = org.mockito.Mockito.mock(BancsResponse.class);

        when(requestMapper.toBancsRequest(request)).thenReturn(bancsBody);
        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class))).thenReturn(Mono.just(bancsResponse));
        when(responseValidator.extractBody(bancsResponse, request.getResourceId())).thenReturn(validatedBody);
        when(responseMapper.toDomain(validatedBody)).thenReturn(expected);

        DemographicsResponseDto result = adapter.execute(request).block();

        assertThat(result).isSameAs(expected);
        verify(requestMapper).toBancsRequest(request);
        verify(responseValidator).extractBody(bancsResponse, request.getResourceId());
        verify(responseMapper).toDomain(validatedBody);
    }

    @Test
    void executeShouldBuildRequestWithoutHeaderWhenBancsUserIsNull() {
        DemographicsRequestDto request = buildRequestWithoutUser();
        BancsDemographicsRequest bancsBody = BancsDemographicsRequest.builder().customerCif("123").build();
        BancsResponse<BancsDemographicsResponse> bancsResponse = org.mockito.Mockito.mock(BancsResponse.class);
        BancsDemographicsResponse validatedBody = BancsDemographicsResponse.builder().build();

        when(requestMapper.toBancsRequest(request)).thenReturn(bancsBody);
        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class))).thenReturn(Mono.just(bancsResponse));
        when(responseValidator.extractBody(any(), any())).thenReturn(validatedBody);
        when(responseMapper.toDomain(validatedBody)).thenReturn(DemographicsResponseDto.builder().code("0").message("OK").build());

        adapter.execute(request).block();

        verify(bancsClientPort).call(bancsRequestCaptor.capture(), eq(BancsDemographicsResponse.class));
        Object header = invokeAccessor(bancsRequestCaptor.getValue(), "header", "getHeader");
        Object transactionId = invokeAccessor(bancsRequestCaptor.getValue(), "transactionId", "getTransactionId");
        assertThat(header).isNull();
        assertThat(transactionId).isEqualTo("061406");
    }

    @Test
    void executeShouldMapTimeoutExceptionToBusinessException() {
        DemographicsRequestDto request = buildRequestWithUser();
        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());
        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class)))
                .thenReturn(Mono.error(new TimeoutException("timeout")));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception.getCode()).isEqualTo("9920");
        assertThat(exception.getMessage()).isEqualTo("Tiempo de espera terminado sin respuesta");
        assertThat(exception.getType()).isEqualTo("FATAL");
        assertThat(exception.getComponent()).isEqualTo(InfrastructureBusinessConstants.COMPONENT_BANCS_TX);
    }

    @Test
    void executeShouldMapWebClientResponseExceptionToBusinessException() {
        DemographicsRequestDto request = buildRequestWithUser();
        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());

        WebClientResponseException responseException = WebClientResponseException.create(
                500,
                "Internal Server Error",
                HttpHeaders.EMPTY,
                "error".getBytes(StandardCharsets.UTF_8),
                StandardCharsets.UTF_8
        );

        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class)))
                .thenReturn(Mono.error(responseException));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception.getCode()).isEqualTo("9928");
        assertThat(exception.getMessage()).contains("ESB-%2% ");
        assertThat(exception.getType()).isEqualTo("FATAL");
        assertThat(exception.getComponent()).isEqualTo(InfrastructureBusinessConstants.COMPONENT_BANCS_ADAPTER);
    }

    @Test
    void executeShouldMapWebClientRequestExceptionToBusinessException() {
        DemographicsRequestDto request = buildRequestWithUser();
        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());

        WebClientRequestException requestException = new WebClientRequestException(
                new IOException("connection error"),
                HttpMethod.POST,
                URI.create("http://localhost/mock"),
                HttpHeaders.EMPTY
        );

        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class)))
                .thenReturn(Mono.error(requestException));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception.getCode()).isEqualTo("9928");
        assertThat(exception.getMessage()).contains("ESB-%2% ");
        assertThat(exception.getType()).isEqualTo("FATAL");
        assertThat(exception.getComponent()).isEqualTo(InfrastructureBusinessConstants.COMPONENT_BANCS_ADAPTER);
    }

    @Test
    void executeShouldMapInvalidCustomerCifDomainErrorTo0282() {
        DemographicsRequestDto request = buildRequestWithUser();
        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());

        RuntimeException domainError = new RuntimeException(
                "BancsIntegrationException httpStatus=501, code=001, businessMessage=Error on: "
                        + "Value [99994545465455243256] is bigger that size [16] for field [customerCIF]"
        );

        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class)))
                .thenReturn(Mono.error(domainError));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception.getCode()).isEqualTo("0282");
        assertThat(exception.getMessage()).isEqualTo("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
        assertThat(exception.getType()).isEqualTo("ERROR");
        assertThat(exception.getBackend()).isEqualTo("00045");
        assertThat(exception.getComponent()).isEqualTo(InfrastructureBusinessConstants.COMPONENT_BANCS_TX);
    }

    @Test
    void executeShouldMapBancsRequestValidationErrorToErrorType() {
        DemographicsRequestDto request = buildRequestWithUser();
        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());

        RuntimeException validationError = new RuntimeException(
                "BancsIntegrationException httpStatus=400, code=001, "
                        + "businessMessage=Body no coincide con Tx061406Rq"
        );

        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class)))
                .thenReturn(Mono.error(validationError));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception.getCode()).isEqualTo("9928");
        assertThat(exception.getType()).isEqualTo("ERROR");
        assertThat(exception.getMessage()).contains("Body no coincide con Tx061406Rq");
    }

    @Test
    void executeShouldMapWebClientBadRequestToErrorType() {
        DemographicsRequestDto request = buildRequestWithUser();
        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());

        WebClientResponseException responseException = WebClientResponseException.create(
                400,
                "Bad Request",
                HttpHeaders.EMPTY,
                "invalid body".getBytes(StandardCharsets.UTF_8),
                StandardCharsets.UTF_8
        );

        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class)))
                .thenReturn(Mono.error(responseException));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception.getCode()).isEqualTo("9928");
        assertThat(exception.getType()).isEqualTo("ERROR");
    }

    @Test
    void executeShouldMapUnexpectedExceptionToBusinessException() {
        DemographicsRequestDto request = buildRequestWithUser();
        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());
        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class)))
                .thenReturn(Mono.error(new IllegalStateException("unexpected")));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception.getCode()).isEqualTo("9928");
        assertThat(exception.getMessage()).contains("unexpected");
        assertThat(exception.getType()).isEqualTo("FATAL");
        assertThat(exception.getComponent()).isEqualTo(InfrastructureBusinessConstants.COMPONENT_BANCS_ADAPTER);
    }

    @Test
    void executeShouldKeepOriginalBusinessException() {
        DemographicsRequestDto request = buildRequestWithUser();
        BusinessException original = new BusinessException("123", "controlled", "resource", "component", "backend");

        when(requestMapper.toBancsRequest(request)).thenReturn(BancsDemographicsRequest.builder().build());
        when(bancsClientPort.call(any(BancsRequest.class), eq(BancsDemographicsResponse.class))).thenReturn(Mono.error(original));

        BusinessException exception = assertThrows(BusinessException.class, () -> adapter.execute(request).block());

        assertThat(exception).isSameAs(original);
    }

    private DemographicsRequestDto buildRequestWithUser() {
        return DemographicsRequestDto.builder()
                .resourceId("OperacionDemograficosCliente61")
                .bancsUser(BancsUserDataDto.builder()
                        .teller("TEL")
                        .terminal("TERM")
                        .institution("INS")
                        .branch("BR")
                        .workstation("WS")
                        .channel("CH")
                        .application("APP")
                        .build())
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer("T")
                        .build())
                .build();
    }

    private DemographicsRequestDto buildRequestWithoutUser() {
        return DemographicsRequestDto.builder()
                .resourceId("OperacionDemograficosCliente61")
                .demographicData(DemographicDataDto.builder()
                        .cif("123")
                        .operation("01")
                        .naturalCustomer("T")
                        .build())
                .build();
    }

        private Object invokeAccessor(Object target, String... methodNames) {
                for (String methodName : methodNames) {
                        try {
                                Method method = target.getClass().getMethod(methodName);
                                return method.invoke(target);
                        } catch (Exception ignored) {
                        }
                }
                throw new IllegalStateException("No compatible accessor found for " + String.join(",", methodNames));
        }
}
