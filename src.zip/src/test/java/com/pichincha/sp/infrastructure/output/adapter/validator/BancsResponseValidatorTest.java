package com.pichincha.sp.infrastructure.output.adapter.validator;

import com.pichincha.bnc.apiclient.dto.response.BancsError;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.sp.domain.exception.BusinessException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class BancsResponseValidatorTest {

    private final BancsResponseValidator validator = new BancsResponseValidator();

    @Test
    void extractBodyShouldReturnBodyWhenResponseIsSuccessful() {
        BancsResponse<String> response = mock(BancsResponse.class);
        when(response.success()).thenReturn(true);
        when(response.body()).thenReturn("ok");

        String result = validator.extractBody(response, "OperacionDemograficosCliente61");

        assertThat(result).isEqualTo("ok");
    }

    @Test
    void extractBodyShouldThrowWhenResponseIsNull() {
        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> validator.extractBody(null, "OperacionDemograficosCliente61")
        );

        assertThat(exception.getCode()).isEqualTo("BANCS_NULL_RESPONSE");
        assertThat(exception.getMessage()).isEqualTo("Null response from BANCS core");
    }

    @Test
    void extractBodyShouldPropagateBusinessErrorWhenCustomerIsNotFound() {
        BancsResponse<String> response = mock(BancsResponse.class);
        BancsError error = mock(BancsError.class);

        when(response.success()).thenReturn(false);
        when(response.body()).thenReturn(null);
        when(response.error()).thenReturn(error);
        when(error.code()).thenReturn("282");
        when(error.message()).thenReturn("NO SE ENCONTRARON REGISTROS DEL CLIENTE");

        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> validator.extractBody(response, "OperacionDemograficosCliente61")
        );

        assertThat(exception.getCode()).isEqualTo("0282");
        assertThat(exception.getMessage()).isEqualTo("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
        assertThat(exception.getType()).isEqualTo("ERROR");
        assertThat(exception.getBackend()).isEqualTo("00045");
    }

    @Test
    void extractBodyShouldMapCustomerNotFoundWhenOnlyBusinessMessageIsPresent() {
        BancsResponse<String> response = mock(BancsResponse.class);
        BancsError error = mock(BancsError.class);

        when(response.success()).thenReturn(false);
        when(response.body()).thenReturn(null);
        when(response.error()).thenReturn(error);
        when(error.code()).thenReturn("500");
        when(error.message()).thenReturn("NO SE ENCONTRARON REGISTROS DEL CLIENTE");

        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> validator.extractBody(response, "OperacionDemograficosCliente61")
        );

        assertThat(exception.getCode()).isEqualTo("0282");
        assertThat(exception.getMessage()).isEqualTo("NO SE ENCONTRARON REGISTROS DEL CLIENTE");
        assertThat(exception.getType()).isEqualTo("ERROR");
    }

    @Test
    void extractBodyShouldReturnBodyWhenSuccessIsFalseButCoreErrorIsPresentInBody() {
        BancsResponse<String> response = mock(BancsResponse.class);
        BancsError error = mock(BancsError.class);
        String bodyWithCoreError = "core-error-body";

        when(response.success()).thenReturn(false);
        when(response.error()).thenReturn(error);
        when(error.code()).thenReturn("282");
        when(response.body()).thenReturn(bodyWithCoreError);

        String result = validator.extractBody(response, "OperacionDemograficosCliente61");

        assertThat(result).isEqualTo(bodyWithCoreError);
    }

    @Test
    void extractBodyShouldThrowFatalWhenServiceUnavailable() {
        BancsResponse<String> response = mock(BancsResponse.class);
        BancsError error = mock(BancsError.class);

        when(response.success()).thenReturn(false);
        when(response.error()).thenReturn(error);
        when(error.code()).thenReturn("503");

        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> validator.extractBody(response, "OperacionDemograficosCliente61")
        );

        assertThat(exception.getCode()).isEqualTo("9929");
        assertThat(exception.getType()).isEqualTo("FATAL");
    }

    @Test
    void extractBodyShouldThrowErrorWhenBodyIsNull() {
        BancsResponse<String> response = mock(BancsResponse.class);
        when(response.success()).thenReturn(true);
        when(response.body()).thenReturn(null);

        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> validator.extractBody(response, "OperacionDemograficosCliente61")
        );

        assertThat(exception.getCode()).isEqualTo("BANCS_NULL_BODY");
        assertThat(exception.getMessage()).isEqualTo("BANCS response without body");
    }
}
