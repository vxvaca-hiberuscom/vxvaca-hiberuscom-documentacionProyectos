package com.pichincha.sp.infrastructure.input.adapter.rest.serialization;

import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.pichincha.sp.generated.Journals;
import com.pichincha.sp.infrastructure.input.adapter.rest.support.JournalsXmlSupport;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class JournalsJacksonXmlSerializerTest {

    @Test
    void shouldSerializeLegacyJournalStructureWithJacksonXml() throws Exception {
        XmlMapper xmlMapper = XmlMapper.builder()
                .defaultUseWrapper(false)
                .build();
        xmlMapper.registerModule(new SimpleModule().addSerializer(Journals.class, new JournalsJacksonXmlSerializer()));

        JournalsHolder holder = new JournalsHolder();
        holder.journals = JournalsXmlSupport.createDefault();

        String xml = xmlMapper.writeValueAsString(holder);

        assertThat(xml).contains("<journals>");
        assertThat(xml).contains("<journal>");
        assertThat(xml).contains("<valor></valor>");
    }

    @SuppressWarnings("unused")
    private static final class JournalsHolder {
        public Journals journals;
    }
}
