package com.pichincha.sp.infrastructure.input.adapter.rest.support;

import com.pichincha.sp.generated.Journals;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import org.junit.jupiter.api.Test;

import java.io.StringWriter;

import static org.assertj.core.api.Assertions.assertThat;

class JournalsXmlSupportTest {

    @Test
    void createDefaultShouldBuildLegacyJournalsStructure() throws Exception {
        Journals journals = JournalsXmlSupport.createDefault();

        assertThat(journals).isNotNull();

        StringWriter writer = new StringWriter();
        Marshaller marshaller = JAXBContext.newInstance(Journals.class).createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
        marshaller.marshal(journals, writer);

        assertThat(writer.toString()).contains("<journal>");
        assertThat(writer.toString()).contains("<valor></valor>");
    }
}
