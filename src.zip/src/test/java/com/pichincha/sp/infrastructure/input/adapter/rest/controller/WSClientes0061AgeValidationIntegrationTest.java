package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.Application;
import com.pichincha.sp.application.port.output.DemographicsCorePort;
import com.pichincha.sp.infrastructure.output.adapter.BancsClientAdapter;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = Application.class,
        properties = {
                "optimus.web.filter.excluded-path-patterns.defaults=/actuator/**",
                "bancs.webclients.primary.base-url=http://localhost",
                "bancs.webclients.primary.max-in-memory-size=1MB",
                "bancs.webclients.primary.connector.max-connections=5"
        }
)
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class WSClientes0061AgeValidationIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private DemographicsCorePort demographicsCorePort;

    @MockitoBean
    @SuppressWarnings("unused")
    private BancsClientAdapter bancsClientAdapter;

    @Test
    void shouldReturn9928ErrorWhenAgeIsNotNumericWithoutCallingBancs() {
        String request = """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:NS1="http://bpichincha.com/servicios">
                  <soapenv:Header/>
                  <soapenv:Body>
                    <NS1:OperacionDemograficosCliente51>
                      <headerIn>
                        <dispositivo>jmeter</dispositivo>
                        <empresa>0010</empresa>
                        <canal>02</canal>
                        <medio>020002</medio>
                        <aplicacion>00270</aplicacion>
                        <agencia>1</agencia>
                        <tipoTransaccion>202000101</tipoTransaccion>
                        <geolocalizacion></geolocalizacion>
                        <usuario>USINTERT</usuario>
                        <unicidad>Pruebas</unicidad>
                        <guid>Prueba</guid>
                        <fechaHora>20180517184120</fechaHora>
                        <filler></filler>
                        <idioma>es-EC</idioma>
                        <sesion>Prueba</sesion>
                        <ip>10.0.94.104</ip>
                        <idCliente>0602370777</idCliente>
                        <tipoIdCliente>0001</tipoIdCliente>
                        <bancs>
                          <teller>90233</teller>
                          <terminal>1</terminal>
                          <institucion>003</institucion>
                          <agencia>1</agencia>
                          <estacion>1</estacion>
                          <aplicacion>02</aplicacion>
                          <canal>02</canal>
                        </bancs>
                      </headerIn>
                      <bodyIn>
                        <demografica>
                          <cif>0000000005783387</cif>
                          <operacion>01</operacion>
                          <clienteNatural>TRUE</clienteNatural>
                          <paisNacimiento>EC</paisNacimiento>
                          <provinciaEstadoNacimiento>EC 06</provinciaEstadoNacimiento>
                          <ciudadNacimiento>070610007</ciudadNacimiento>
                          <fechaNacimiento></fechaNacimiento>
                          <edad>hola</edad>
                          <sexo>1</sexo>
                          <estadoCivil>1</estadoCivil>
                          <separacionBienes></separacionBienes>
                          <nivelEstudios></nivelEstudios>
                          <profesion>200</profesion>
                          <numeroCargasFamiliares>000</numeroCargasFamiliares>
                          <tipoVivienda>0</tipoVivienda>
                          <domicilioCuentaEscrituraslegalizadas></domicilioCuentaEscrituraslegalizadas>
                          <domicilioConServiciosBasicos></domicilioConServiciosBasicos>
                          <nombreCompletoDuenioCasa></nombreCompletoDuenioCasa>
                          <caracteristicasDomicilio></caracteristicasDomicilio>
                          <tiempoResidencia></tiempoResidencia>
                          <sectorDomicilioCliente></sectorDomicilioCliente>
                        </demografica>
                      </bodyIn>
                    </NS1:OperacionDemograficosCliente51>
                  </soapenv:Body>
                </soapenv:Envelope>
                """;

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(request)
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .value(body -> {
                    org.assertj.core.api.Assertions.assertThat(body).contains("<codigo>9928</codigo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("Body no coincide con Tx061406Rq");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<tipo>ERROR</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).contains("<mensajeNegocio/>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain("<tipo>FATAL</tipo>");
                    org.assertj.core.api.Assertions.assertThat(body).doesNotContain(
                            "Existe un inconveniente para ejecutar tu transacción");
                });

        verify(demographicsCorePort, never()).execute(any());
    }
}
