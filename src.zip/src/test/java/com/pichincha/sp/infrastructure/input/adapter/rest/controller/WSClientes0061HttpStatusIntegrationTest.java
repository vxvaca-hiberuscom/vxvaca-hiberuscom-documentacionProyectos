package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.Application;
import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import com.pichincha.sp.infrastructure.output.adapter.BancsClientAdapter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = Application.class,
    properties = {
            "optimus.web.filter.excluded-path-patterns.defaults=/actuator/**",
            "bancs.webclients.primary.base-url=http://localhost",
            "bancs.webclients.primary.max-in-memory-size=1MB",
            "bancs.webclients.primary.connector.max-connections=5"
    }
)
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class WSClientes0061HttpStatusIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private ProcessDemographicsPort processDemographicsPort;

    @MockitoBean
    private SoapDemographicsMapper soapDemographicsMapper;

    @MockitoBean
    @SuppressWarnings("unused")
    private BancsClientAdapter bancsClientAdapter;

    @BeforeEach
    void setupMocks() {
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString())).thenReturn(new SoapEnvelopeResponse());
    }

    @Test
    void shouldValidateHttpStatus200OnKnownEndpoint() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapRequest())
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.TEXT_XML);
    }

    @Test
    void shouldValidateHttpStatus404OnMissingEndpoint() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061-missing")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapRequest())
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void shouldValidateHttpStatus500OnUnhandledError() {
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString()))
                .thenThrow(new AssertionError("Forced integration error for HTTP500"));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(minimalSoapRequest())
                .exchange()
                .expectStatus().is5xxServerError()
                .expectStatus().isEqualTo(500);
    }

    private String minimalSoapRequest() {
        return """
                <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">
                    <soapenv:Header/>
                    <soapenv:Body/>
                </soapenv:Envelope>
                """;
    }
}
