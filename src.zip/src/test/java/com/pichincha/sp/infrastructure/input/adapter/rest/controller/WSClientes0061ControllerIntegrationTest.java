package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.Application;
import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import com.pichincha.sp.infrastructure.output.adapter.BancsClientAdapter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = Application.class,
    properties = {
            "optimus.web.filter.excluded-path-patterns.defaults=/actuator/**",
            "bancs.webclients.primary.base-url=http://localhost",
            "bancs.webclients.primary.max-in-memory-size=1MB",
            "bancs.webclients.primary.connector.max-connections=5"
    }
)
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class WSClientes0061ControllerIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private ProcessDemographicsPort processDemographicsPort;

    @MockitoBean
    private SoapDemographicsMapper soapDemographicsMapper;

    @MockitoBean
    @SuppressWarnings("unused")
    private BancsClientAdapter bancsClientAdapter;

    @BeforeEach
    void setUp() {
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString())).thenReturn(new SoapEnvelopeResponse());
    }

    @Test
    void shouldReturnOkStatusForKnownSoapEndpoint() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithoutOperation())
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.TEXT_XML)
                .expectBody(String.class).consumeWith(result -> {
                    String body = result.getResponseBody();
                    if (body != null) {
                        org.assertj.core.api.Assertions.assertThat(body).contains("Envelope");
                    }
                });
    }

    @Test
    void shouldReturnHttp404ForUnknownEndpoint() {
        webTestClient.post()
                .uri("/IntegrationBus/soap/not-found")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithoutOperation())
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void shouldReturnHttp500WhenUnhandledErrorOccurs() {
        when(soapDemographicsMapper.toErrorSoapEnvelope(anyString()))
                .thenThrow(new AssertionError("Forced integration error"));

        webTestClient.post()
                .uri("/IntegrationBus/soap/WSClientes0061")
                .contentType(MediaType.TEXT_XML)
                .accept(MediaType.TEXT_XML)
                .bodyValue(soapRequestWithoutOperation())
                .exchange()
                .expectStatus().is5xxServerError()
                .expectStatus().isEqualTo(500);
    }

    private String soapRequestWithoutOperation() {
        return """
                <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">
                    <soapenv:Header/>
                    <soapenv:Body/>
                </soapenv:Envelope>
                """;
    }
}
