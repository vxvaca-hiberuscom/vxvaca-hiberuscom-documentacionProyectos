package com.pichincha.sp.infrastructure.input.adapter.rest.dto.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.pichincha.sp.generated.OperacionDemograficosCliente51Response;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapBodyResponse {

    @XmlElement(name = "OperacionDemograficosCliente51Response", namespace = "http://bpichincha.com/servicios")
    @JacksonXmlProperty(localName = "OperacionDemograficosCliente51Response", namespace = "http://bpichincha.com/servicios")
    private OperacionDemograficosCliente51Response operacionDemograficosCliente51Response;
}