package com.pichincha.sp.infrastructure.output.adapter.validator;

import com.pichincha.bnc.apiclient.dto.response.BancsError;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class BancsResponseValidator {

    private static final String COMPONENT = InfrastructureBusinessConstants.COMPONENT_BANCS_VALIDATOR;

    @Value("${wsclientes0061.bancs.backend-code-business:00045}")
    private String backendCodeBusiness = "00045";

    @Value("${wsclientes0061.bancs.null-response-code:BANCS_NULL_RESPONSE}")
    private String bancsNullResponseCode = "BANCS_NULL_RESPONSE";

    @Value("${wsclientes0061.bancs.invocation-code:9929}")
    private String bancsInvocationCode = "9929";

    @Value("${wsclientes0061.bancs.null-body-code:BANCS_NULL_BODY}")
    private String bancsNullBodyCode = "BANCS_NULL_BODY";

    @Value("${wsclientes0061.soap.fatal-type:FATAL}")
    private String soapFatalType = "FATAL";

    @Value("${wsclientes0061.soap.error-type:ERROR}")
    private String soapErrorType = "ERROR";

    @Value("${wsclientes0061.bancs.http-code-service-unavailable:503}")
    private String bancsHttpCodeServiceUnavailable = "503";

    @Value("${wsclientes0061.bancs.null-response-message:Null response from BANCS core}")
    private String bancsNullResponseMessage = "Null response from BANCS core";

    @Value("${wsclientes0061.bancs.invocation-message:Error al invocar transaccion Bancs}")
    private String bancsInvocationMessage = "Error al invocar transaccion Bancs";

    @Value("${wsclientes0061.bancs.null-body-message:BANCS response without body}")
    private String bancsNullBodyMessage = "BANCS response without body";

    @Value("${wsclientes0061.validation.customer-not-found-code:0282}")
    private String customerNotFoundCode = "0282";

    @Value("${wsclientes0061.validation.customer-not-found-message:NO SE ENCONTRARON REGISTROS DEL CLIENTE}")
    private String customerNotFoundMessage = "NO SE ENCONTRARON REGISTROS DEL CLIENTE";

    @BpLogger
    public <T> T extractBody(BancsResponse<T> response, String resourceId) {
        if (response == null) {
            throw new BusinessException(
                bancsNullResponseCode,
                bancsNullResponseMessage,
                    resourceId,
                    COMPONENT,
                    backendCodeBusiness
            );
        }

        if (Boolean.FALSE.equals(response.success())) {
            BancsError error = response.error();
            if (isServiceUnavailable(error)) {
                throw new BusinessException(
                        bancsInvocationCode,
                        bancsInvocationMessage,
                        soapFatalType,
                        resourceId,
                        InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                        backendCodeBusiness
                );
            }
            if (response.body() != null) {
                return response.body();
            }
            if (hasResolvableBusinessError(error)) {
                throw buildBusinessExceptionFromBancsError(error, resourceId);
            }
            throw new BusinessException(
                    bancsInvocationCode,
                    bancsInvocationMessage,
                    soapErrorType,
                    resourceId,
                    InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                    backendCodeBusiness
            );
        }

        if (response.body() == null) {
            throw new BusinessException(
            bancsNullBodyCode,
            bancsNullBodyMessage,
                    resourceId,
                    COMPONENT,
                    backendCodeBusiness
            );
        }

        return response.body();
    }

    private BusinessException buildBusinessExceptionFromBancsError(BancsError error, String resourceId) {
        String businessCode = BancsErrorExtractor.extractBusinessCode(error);
        String extractedMessage = BancsErrorExtractor.extractMessage(error);
        if (businessCode.isBlank() && isCustomerNotFoundMessage(extractedMessage)) {
            businessCode = customerNotFoundCode;
        }
        String message = resolveErrorMessage(error, businessCode, extractedMessage);

        return new BusinessException(
                businessCode,
                message,
                soapErrorType,
                resourceId,
                InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                backendCodeBusiness
        );
    }

    private String resolveErrorMessage(BancsError error, String businessCode, String extractedMessage) {
        if (!extractedMessage.isBlank()) {
            return extractedMessage;
        }
        if (customerNotFoundCode.equals(businessCode)) {
            return customerNotFoundMessage;
        }
        return bancsInvocationMessage;
    }

    private boolean hasResolvableBusinessError(BancsError error) {
        if (error == null) {
            return false;
        }
        if (!BancsErrorExtractor.extractBusinessCode(error).isBlank()) {
            return true;
        }
        return isCustomerNotFoundMessage(BancsErrorExtractor.extractMessage(error));
    }

    private boolean isCustomerNotFoundMessage(String message) {
        if (message == null || message.isBlank()) {
            return false;
        }
        return message.toUpperCase().contains(customerNotFoundMessage);
    }

    private boolean isServiceUnavailable(BancsError error) {
        if (error == null || error.code() == null) {
            return false;
        }
        return bancsHttpCodeServiceUnavailable.equals(error.code().trim());
    }
}
