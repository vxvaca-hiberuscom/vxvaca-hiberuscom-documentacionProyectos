package com.pichincha.sp.infrastructure.config;

import com.fasterxml.jackson.databind.module.SimpleModule;
import com.pichincha.sp.generated.Journals;
import com.pichincha.sp.infrastructure.input.adapter.rest.serialization.JournalsJacksonXmlSerializer;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SoapJacksonXmlConfig {

    @Bean
    Jackson2ObjectMapperBuilderCustomizer journalsJacksonXmlCustomizer() {
        return builder -> builder.modulesToInstall(new SimpleModule()
                .addSerializer(Journals.class, new JournalsJacksonXmlSerializer()));
    }
}
