package com.pichincha.sp.infrastructure.input.adapter.rest.validator;

import java.util.List;

final class DemograficaElementOrder {

    static final List<String> XSD_SEQUENCE = List.of(
            "cif",
            "operacion",
            "clienteNatural",
            "paisNacimiento",
            "provinciaEstadoNacimiento",
            "ciudadNacimiento",
            "fechaNacimiento",
            "edad",
            "sexo",
            "estadoCivil",
            "separacionBienes",
            "nivelEstudios",
            "profesion",
            "numeroCargasFamiliares",
            "tipoVivienda",
            "domicilioCuentaEscrituraslegalizadas",
            "domicilioConServiciosBasicos",
            "nombreCompletoDuenioCasa",
            "caracteristicasDomicilio",
            "tiempoResidencia",
            "sectorDomicilioCliente"
    );

    private DemograficaElementOrder() {
    }
}
