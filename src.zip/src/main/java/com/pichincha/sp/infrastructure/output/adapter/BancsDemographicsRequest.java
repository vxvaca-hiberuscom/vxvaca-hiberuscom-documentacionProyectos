package com.pichincha.sp.infrastructure.output.adapter;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

@Builder
public record BancsDemographicsRequest(
        @JsonProperty("customerCIF")
        String customerCif,
        @JsonProperty("operacion")
        String operation,
        @JsonProperty("clienteNatural")
        String naturalCustomer,
        @JsonProperty("paisNacimiento")
        String countryOfBirth,
        @JsonProperty("provinciaEstadoNacimiento")
        String birthStateProvince,
        @JsonProperty("ciudadNacimiento")
        String birthCity,
        @JsonProperty("fechaNacimiento")
        String birthDate,
        @JsonProperty("edad")
        String age,
        @JsonProperty("sexo")
        String gender,
        @JsonProperty("estadoCivil")
        String maritalStatus,
        @JsonProperty("separacionBienes")
        String propertySeparation,
        @JsonProperty("nivelEstudios")
        String educationLevel,
        @JsonProperty("profesion")
        String profession,
        @JsonProperty("numeroCargasFamiliares")
        String familyDependents,
        @JsonProperty("tipoVivienda")
        String housingType,
        @JsonProperty("domicilioCuentaEscrituraslegalizadas")
        String legalDeedsAtAddress,
        @JsonProperty("domicilioConServiciosBasicos")
        String basicServicesAtAddress,
        @JsonProperty("nombreCompletoDuenioCasa")
        String houseOwnerName,
        @JsonProperty("caracteristicasDomicilio")
        String addressFeatures,
        @JsonProperty("tiempoResidencia")
        String residenceTime,
        @JsonProperty("sectorDomicilioCliente")
        String clientAddressSector
) {
}
