package com.pichincha.sp.infrastructure.output.adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public record BancsDemographicsResponse(
        @JsonProperty("paisNacimiento")
        String countryOfBirth,
        @JsonProperty("provinciaEstadoNacimiento")
        String birthStateProvince,
        @JsonProperty("ciudadNacimiento")
        String birthCity,
        @JsonProperty("fechaNacimiento")
        String birthDate,
        @JsonProperty("edad")
        Integer age,
        @JsonProperty("sexo")
        String gender,
        @JsonProperty("estadoCivil")
        String maritalStatus,
        @JsonProperty("separacionBienes")
        String propertySeparation,
        @JsonProperty("nivelEstudios")
        String educationLevel,
        @JsonProperty("profesion")
        String profession,
        @JsonProperty("numeroCargasFamiliares")
        Integer familyDependents,
        @JsonProperty("tipoVivienda")
        String housingType,
        @JsonProperty("domicilioCuentaEscrituraslegalizadas")
        String legalDeedsAtAddress,
        @JsonProperty("domicilioConServiciosBasicos")
        String basicServicesAtAddress,
        @JsonProperty("nombreCompletoDuenioCasa")
        String houseOwnerName,
        @JsonProperty("caracteristicasDomicilio")
        String addressFeatures,
        @JsonProperty("tiempoResidencia")
        String residenceTime,
        @JsonProperty("sectorDomicilioCliente")
        String clientAddressSector,
        @JsonProperty("codError")
        Integer coreErrorCode,
        @JsonProperty("descError")
        String coreErrorDescription
) {
}
