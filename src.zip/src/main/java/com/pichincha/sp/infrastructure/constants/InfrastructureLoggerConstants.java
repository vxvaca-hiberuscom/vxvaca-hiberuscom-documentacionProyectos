package com.pichincha.sp.infrastructure.constants;

public final class InfrastructureLoggerConstants {

    private InfrastructureLoggerConstants() {
    }

    public static final String LOG_START_SOAP_REQUEST = "Start SOAP request processing";
    public static final String LOG_COMPLETE_SOAP_REQUEST = "SOAP request processing completed";
    public static final String LOG_ERROR_SOAP_REQUEST = "SOAP request processing failed";

    public static final String LOG_START_BANCS_REQUEST = "Start BANCS request for resource={} transactionId={}";
    public static final String LOG_COMPLETE_BANCS_REQUEST = "BANCS request completed for resource={} transactionId={}";
    public static final String LOG_ERROR_BANCS_REQUEST = "BANCS request failed for resource={} transactionId={}";
}
