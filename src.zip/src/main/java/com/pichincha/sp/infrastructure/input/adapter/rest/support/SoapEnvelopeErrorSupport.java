package com.pichincha.sp.infrastructure.input.adapter.rest.support;

import org.springframework.core.codec.DecodingException;
import org.springframework.web.server.ServerWebInputException;

final class SoapEnvelopeErrorSupport {

    private SoapEnvelopeErrorSupport() {
    }

    static boolean isEnvelopeParsingError(Throwable throwable) {
        Throwable current = throwable;
        while (current != null) {
            if (current instanceof ServerWebInputException || current instanceof DecodingException) {
                return true;
            }
            String exceptionName = current.getClass().getName();
            if (exceptionName.contains("XMLStreamException")
                    || exceptionName.contains("JsonMappingException")
                    || exceptionName.contains("JsonParseException")
                    || exceptionName.contains("JsonProcessingException")
                    || exceptionName.contains("MismatchedInputException")) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }
}
