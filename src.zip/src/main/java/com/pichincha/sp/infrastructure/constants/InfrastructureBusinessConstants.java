package com.pichincha.sp.infrastructure.constants;

public final class InfrastructureBusinessConstants {

    private InfrastructureBusinessConstants() {
    }

    public static final String BACKEND_BANCS = "BANCS";
    public static final String RESOURCE_DEMOGRAPHICS_OPERATION = "WSClientes0061/OperacionDemograficosCliente61";
    public static final String SOAP_RESOURCE_DEMOGRAPHICS_OPERATION = "tnd-msa-sp-wsclientes0061/OperacionDemograficosCliente61";
    public static final String RESOURCE_UMP_DEMOGRAPHICS_OPERATION = "UMPClientes0077/OperacionDemograficosCliente61";
    public static final String COMPONENT_WSCLIENTES = "sqb-msa-wsclientes0061";
    public static final String COMPONENT_WSCLIENTES_UPPER = "sqb-msa-wsclientes0061";
    public static final String SOAP_COMPONENT_WSCLIENTES = "tnd-msa-sp-wsclientes0061";
    public static final String COMPONENT_OPERATION = "OperacionDemograficosCliente61";
    public static final String COMPONENT_BANCS_ADAPTER = "BANCS_ADAPTER";
    public static final String COMPONENT_BANCS_VALIDATOR = "BANCS_VALIDATOR";
    public static final String COMPONENT_BANCS_TX = "061406";
    public static final String SUCCESS_CODE = "0";
    public static final String SUCCESS_MESSAGE = "Ok";
    public static final String EMPTY = "";
}
