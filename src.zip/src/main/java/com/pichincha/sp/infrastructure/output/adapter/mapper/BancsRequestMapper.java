package com.pichincha.sp.infrastructure.output.adapter.mapper;

import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.infrastructure.output.adapter.BancsDemographicsRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BancsRequestMapper {

    @Mapping(target = "customerCif", source = "demographicData.cif")
    @Mapping(target = "operation", source = "demographicData.operation")
    @Mapping(target = "naturalCustomer", source = "demographicData.naturalCustomer")
    @Mapping(target = "countryOfBirth", source = "demographicData.countryOfBirth")
    @Mapping(target = "birthStateProvince", source = "demographicData.birthStateProvince")
    @Mapping(target = "birthCity", source = "demographicData.birthCity")
    @Mapping(target = "birthDate", source = "demographicData.birthDate")
    @Mapping(target = "age", source = "demographicData.age")
    @Mapping(target = "gender", source = "demographicData.gender")
    @Mapping(target = "maritalStatus", source = "demographicData.maritalStatus")
    @Mapping(target = "propertySeparation", source = "demographicData.propertySeparation")
    @Mapping(target = "educationLevel", source = "demographicData.educationLevel")
    @Mapping(target = "profession", source = "demographicData.profession")
    @Mapping(target = "familyDependents", source = "demographicData.familyDependents")
    @Mapping(target = "housingType", source = "demographicData.housingType")
    @Mapping(target = "legalDeedsAtAddress", source = "demographicData.legalDeedsAtAddress")
    @Mapping(target = "basicServicesAtAddress", source = "demographicData.basicServicesAtAddress")
    @Mapping(target = "houseOwnerName", source = "demographicData.houseOwnerName")
    @Mapping(target = "addressFeatures", source = "demographicData.addressFeatures")
    @Mapping(target = "residenceTime", source = "demographicData.residenceTime")
    @Mapping(target = "clientAddressSector", source = "demographicData.clientAddressSector")
    BancsDemographicsRequest toBancsRequest(DemographicsRequestDto request);
}
