package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.bnc.apiclient.adapter.BancsClient;
import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class BancsClientAdapter implements BancsClientPort {

    private final BancsClient bancsClient;

    @Override
    public <T> Mono<BancsResponse<T>> call(BancsRequest<?> request, Class<T> responseType) {
        return bancsClient.call(request, responseType);
    }
}
