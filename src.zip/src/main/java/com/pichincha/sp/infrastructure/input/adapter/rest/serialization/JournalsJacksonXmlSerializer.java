package com.pichincha.sp.infrastructure.input.adapter.rest.serialization;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.pichincha.sp.generated.Journals;

import java.io.IOException;

/**
 * JAXB-generated {@link Journals} hides its {@code journal} list from Jackson XML.
 * This serializer emits the legacy structure expected in {@code headerOut/documento/journals}.
 */
public class JournalsJacksonXmlSerializer extends JsonSerializer<Journals> {

    @Override
    public void serialize(Journals value, JsonGenerator generator, SerializerProvider serializers) throws IOException {
        generator.writeFieldName("journal");
        generator.writeStartObject();
        generator.writeStringField("valor", "");
        generator.writeEndObject();
    }
}
