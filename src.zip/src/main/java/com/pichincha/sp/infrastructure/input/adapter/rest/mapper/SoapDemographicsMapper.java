package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.pichincha.sp.domain.dto.BancsUserDataDto;
import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.generated.BancsTeller;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.BodyOutOperacionDemograficosCliente51;
import com.pichincha.sp.generated.Demografica;
import com.pichincha.sp.generated.GenericError;
import com.pichincha.sp.generated.GenericHeaderOut;
import com.pichincha.sp.generated.OperacionDemograficosCliente51;
import com.pichincha.sp.generated.OperacionDemograficosCliente51Response;
import com.pichincha.sp.generated.TransaccionFinancieraType;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapBodyResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapHeaderResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.support.JournalsXmlSupport;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SoapDemographicsMapper {

    private static final String DEFAULT_RESOURCE = InfrastructureBusinessConstants.SOAP_RESOURCE_DEMOGRAPHICS_OPERATION;
    private static final String DEFAULT_COMPONENT = InfrastructureBusinessConstants.SOAP_COMPONENT_WSCLIENTES;
    private static final String BUSINESS_MESSAGE_PREFIX_PATTERN = "^TCSBRKR\\d+_BP-";

    @Value("${wsclientes0061.bancs.backend-code-esb:00638}")
    private String defaultBackend = "00638";

    @Value("${wsclientes0061.bancs.backend-code-business:00045}")
    private String backendCodeBusiness = "00045";

    @Value("${wsclientes0061.soap.default-error-code:999}")
    private String defaultErrorCode = "999";

    @Value("${wsclientes0061.soap.error-type:ERROR}")
    private String soapErrorType = "ERROR";

    @Value("${wsclientes0061.soap.fatal-type:FATAL}")
    private String soapFatalType = "FATAL";

    @Value("${wsclientes0061.soap.info-type:INFO}")
    private String soapInfoType = "INFO";

    @Value("${wsclientes0061.soap.missing-teller-code:9927}")
    private String missingTellerCode = "9927";

    @Value("${wsclientes0061.soap.missing-teller-message:Datos de la cabecera de la transaccion no se han asignado}")
    private String missingTellerMessage = "Datos de la cabecera de la transaccion no se han asignado";

    @Value("${wsclientes0061.soap.default-business-error-message:Existe un inconveniente para ejecutar tu transacción. Por favor intenta más tarde.}")
    private String defaultBusinessErrorMessage = "Existe un inconveniente para ejecutar tu transacción. Por favor intenta más tarde.";

    @Value("${wsclientes0061.soap.default-error-message:Unexpected SOAP processing error}")
    private String defaultErrorMessage = "Unexpected SOAP processing error";

    public DemographicsRequestDto toDomain(OperacionDemograficosCliente51 request) {
        Demografica input = request.getBodyIn().getDemografica();
        validateMandatoryDemographicFields(input);
        GenericHeaderIn headerIn = request.getHeaderIn();
        BancsTeller bancsTeller = extractBancsTeller(headerIn);
        validateBancsTeller(bancsTeller);
        String resolvedApplication = selectPreferredValue(
                bancsTeller.getAplicacion(),
                headerIn != null ? headerIn.getAplicacion() : null
        );
        String resolvedChannel = selectPreferredValue(
                bancsTeller.getCanal(),
                headerIn != null ? headerIn.getCanal() : null
        );

        BancsUserDataDto bancsUserData = BancsUserDataDto.builder()
            .teller(bancsTeller.getTeller())
            .terminal(bancsTeller.getTerminal())
            .institution(bancsTeller.getInstitucion())
            .branch(bancsTeller.getAgencia())
            .workstation(bancsTeller.getEstacion())
            .application(resolvedApplication)
            .channel(resolvedChannel)
            .build();

            DemographicDataDto demographicData = DemographicDataDto.builder()
                .cif(input.getCif())
                .operation(input.getOperacion())
                .naturalCustomer(input.getClienteNatural())
                .countryOfBirth(input.getPaisNacimiento())
                .birthStateProvince(input.getProvinciaEstadoNacimiento())
                .birthCity(input.getCiudadNacimiento())
                .birthDate(input.getFechaNacimiento())
                .age(input.getEdad())
                .gender(input.getSexo())
                .maritalStatus(input.getEstadoCivil())
                .propertySeparation(input.getSeparacionBienes())
                .educationLevel(input.getNivelEstudios())
                .profession(input.getProfesion())
                .familyDependents(input.getNumeroCargasFamiliares())
                .housingType(input.getTipoVivienda())
                .legalDeedsAtAddress(input.getDomicilioCuentaEscrituraslegalizadas())
                .basicServicesAtAddress(input.getDomicilioConServiciosBasicos())
                .houseOwnerName(input.getNombreCompletoDuenioCasa())
                .addressFeatures(input.getCaracteristicasDomicilio())
                .residenceTime(input.getTiempoResidencia())
                .clientAddressSector(input.getSectorDomicilioCliente())
                .build();

        return DemographicsRequestDto.builder()
                .resourceId(InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION)
                .demographicData(demographicData)
            .bancsUser(bancsUserData)
                .build();
    }

    public SoapEnvelopeResponse toSoapEnvelopeResponse(DemographicsResponseDto response, GenericHeaderIn requestHeader) {
        Demografica outputDemographic = new Demografica();
        if (response.getDemographicData() != null) {
            outputDemographic.setPaisNacimiento(response.getDemographicData().getCountryOfBirth());
            outputDemographic.setProvinciaEstadoNacimiento(response.getDemographicData().getBirthStateProvince());
            outputDemographic.setCiudadNacimiento(response.getDemographicData().getBirthCity());
            outputDemographic.setFechaNacimiento(response.getDemographicData().getBirthDate());
            outputDemographic.setEdad(response.getDemographicData().getAge());
            outputDemographic.setSexo(response.getDemographicData().getGender());
            outputDemographic.setEstadoCivil(response.getDemographicData().getMaritalStatus());
            outputDemographic.setSeparacionBienes(response.getDemographicData().getPropertySeparation());
            outputDemographic.setNivelEstudios(response.getDemographicData().getEducationLevel());
            outputDemographic.setProfesion(response.getDemographicData().getProfession());
            outputDemographic.setNumeroCargasFamiliares(response.getDemographicData().getFamilyDependents());
            outputDemographic.setTipoVivienda(response.getDemographicData().getHousingType());
            outputDemographic.setDomicilioCuentaEscrituraslegalizadas(response.getDemographicData().getLegalDeedsAtAddress());
            outputDemographic.setDomicilioConServiciosBasicos(response.getDemographicData().getBasicServicesAtAddress());
            outputDemographic.setNombreCompletoDuenioCasa(response.getDemographicData().getHouseOwnerName());
            outputDemographic.setCaracteristicasDomicilio(response.getDemographicData().getAddressFeatures());
            outputDemographic.setTiempoResidencia(response.getDemographicData().getResidenceTime());
            outputDemographic.setSectorDomicilioCliente(response.getDemographicData().getClientAddressSector());
        }

        BodyOutOperacionDemograficosCliente51 bodyOut = new BodyOutOperacionDemograficosCliente51();
        bodyOut.setDemografica(outputDemographic);

        GenericError error = new GenericError();
        error.setCodigo(response.getCode());
        error.setMensaje(normalizeMessage(response.getMessage()));
        error.setMensajeNegocio(InfrastructureBusinessConstants.EMPTY);
        error.setTipo(soapInfoType);
        error.setRecurso(InfrastructureBusinessConstants.SOAP_RESOURCE_DEMOGRAPHICS_OPERATION);
        error.setComponente(InfrastructureBusinessConstants.SOAP_COMPONENT_WSCLIENTES);
        error.setBackend(defaultBackend);

        OperacionDemograficosCliente51Response operationResponse = new OperacionDemograficosCliente51Response();
        operationResponse.setHeaderOut(buildHeaderOut(requestHeader));
        operationResponse.setBodyOut(bodyOut);
        operationResponse.setError(error);

        SoapBodyResponse soapBodyResponse = new SoapBodyResponse();
        soapBodyResponse.setOperacionDemograficosCliente51Response(operationResponse);

        SoapEnvelopeResponse envelope = new SoapEnvelopeResponse();
        envelope.setHeader(new SoapHeaderResponse());
        envelope.setBody(soapBodyResponse);
        return envelope;
    }

    public SoapEnvelopeResponse toErrorSoapEnvelope(String errorMessage) {
        return buildErrorEnvelope(
                defaultErrorCode,
                normalizeMessage(errorMessage),
                soapErrorType,
                DEFAULT_RESOURCE,
                DEFAULT_COMPONENT,
            defaultBackend,
            null
        );
    }

    public SoapEnvelopeResponse toErrorSoapEnvelope(BusinessException exception) {
        return buildErrorEnvelope(
                normalizeValue(exception.getCode(), defaultErrorCode),
                normalizeMessage(exception.getMessage()),
                normalizeValue(exception.getType(), soapErrorType),
                DEFAULT_RESOURCE,
                DEFAULT_COMPONENT,
            normalizeValue(exception.getBackend(), defaultBackend),
            null
        );
        }

        public SoapEnvelopeResponse toErrorSoapEnvelope(BusinessException exception, GenericHeaderIn requestHeader) {
        return buildErrorEnvelope(
            normalizeValue(exception.getCode(), defaultErrorCode),
            normalizeMessage(exception.getMessage()),
                normalizeValue(exception.getType(), soapErrorType),
            DEFAULT_RESOURCE,
            DEFAULT_COMPONENT,
            normalizeValue(exception.getBackend(), defaultBackend),
            requestHeader
        );
    }

        private SoapEnvelopeResponse buildErrorEnvelope(
            String code,
            String message,
            String type,
            String resource,
            String component,
            String backend,
            GenericHeaderIn requestHeader
        ) {
        GenericError error = new GenericError();
        error.setCodigo(code);
        error.setMensaje(message);
        error.setMensajeNegocio(InfrastructureBusinessConstants.EMPTY);
        error.setTipo(type);
        error.setRecurso(resource);
        error.setComponente(component);
        error.setBackend(backend);

        OperacionDemograficosCliente51Response operationResponse = new OperacionDemograficosCliente51Response();
    operationResponse.setHeaderOut(buildHeaderOut(requestHeader));
        operationResponse.setError(error);

        SoapBodyResponse soapBodyResponse = new SoapBodyResponse();
        soapBodyResponse.setOperacionDemograficosCliente51Response(operationResponse);

        SoapEnvelopeResponse envelope = new SoapEnvelopeResponse();
        envelope.setHeader(new SoapHeaderResponse());
        envelope.setBody(soapBodyResponse);
        return envelope;
    }

    private String normalizeMessage(String message) {
        String normalized = normalizeValue(message, defaultErrorMessage);
        return normalized.replaceFirst(BUSINESS_MESSAGE_PREFIX_PATTERN, InfrastructureBusinessConstants.EMPTY);
    }

    private static String normalizeValue(String value, String defaultValue) {
        return value == null || value.isBlank() ? defaultValue : value;
    }

    private GenericHeaderOut buildHeaderOut(GenericHeaderIn headerIn) {
        GenericHeaderIn sourceHeader = headerIn != null ? headerIn : new GenericHeaderIn();
        GenericHeaderOut headerOut = new GenericHeaderOut();
        headerOut.setDispositivo(normalizeValue(sourceHeader.getDispositivo(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setEmpresa(normalizeValue(sourceHeader.getEmpresa(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setCanal(normalizeValue(sourceHeader.getCanal(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setMedio(normalizeValue(sourceHeader.getMedio(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setAplicacion(normalizeValue(sourceHeader.getAplicacion(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setAgencia(normalizeValue(sourceHeader.getAgencia(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setTipoTransaccion(normalizeValue(sourceHeader.getTipoTransaccion(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setGeolocalizacion(normalizeValue(sourceHeader.getGeolocalizacion(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setUsuario(normalizeValue(sourceHeader.getUsuario(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setUnicidad(normalizeValue(sourceHeader.getUnicidad(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setGuid(normalizeValue(sourceHeader.getGuid(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setFechaHora(normalizeValue(sourceHeader.getFechaHora(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setFiller(normalizeValue(sourceHeader.getFiller(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setIdioma(normalizeValue(sourceHeader.getIdioma(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setSesion(normalizeValue(sourceHeader.getSesion(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setIp(normalizeValue(sourceHeader.getIp(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setIdCliente(normalizeValue(sourceHeader.getIdCliente(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setTipoIdCliente(normalizeValue(sourceHeader.getTipoIdCliente(), InfrastructureBusinessConstants.EMPTY));
        headerOut.setBancs(sourceHeader.getBancs());

        TransaccionFinancieraType document = new TransaccionFinancieraType();
        document.setFechaContable(InfrastructureBusinessConstants.EMPTY);
        document.setNumeroDocumento(InfrastructureBusinessConstants.EMPTY);
        document.setJournals(JournalsXmlSupport.createDefault());
        headerOut.setDocumento(document);

        return headerOut;
    }

    private BancsTeller extractBancsTeller(GenericHeaderIn headerIn) {
        if (headerIn == null) {
            return null;
        }
        return headerIn.getBancs();
    }

    private void validateMandatoryDemographicFields(Demografica input) {
        if (input == null) {
            throw new SoapInputFaultException("Missing mandatory block: demografica");
        }
        if (input.getCif() == null) {
            throw new SoapInputFaultException("Missing mandatory field: cif");
        }
        if (input.getOperacion() == null) {
            throw new SoapInputFaultException("Missing mandatory field: operacion");
        }
    }

    private void validateBancsTeller(BancsTeller bancsTeller) {
        if (bancsTeller == null || bancsTeller.getTeller() == null || bancsTeller.getTeller().isBlank()) {
            throw new BusinessException(
                    missingTellerCode,
                    missingTellerMessage,
                    soapErrorType,
                    InfrastructureBusinessConstants.SOAP_RESOURCE_DEMOGRAPHICS_OPERATION,
                    InfrastructureBusinessConstants.SOAP_COMPONENT_WSCLIENTES,
                    backendCodeBusiness
            );
        }
    }

    private static String selectPreferredValue(String primaryValue, String fallbackValue) {
        if (primaryValue != null && !primaryValue.isBlank()) {
            return primaryValue;
        }
        return fallbackValue;
    }
}
