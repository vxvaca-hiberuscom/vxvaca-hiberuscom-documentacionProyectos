package com.pichincha.sp.infrastructure.input.adapter.rest.config;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.http.codec.xml.Jackson2XmlDecoder;
import org.springframework.http.codec.xml.Jackson2XmlEncoder;
import org.springframework.web.reactive.config.WebFluxConfigurer;

@Configuration
@RequiredArgsConstructor
public class SoapWebFluxXmlCodecConfig implements WebFluxConfigurer {

    private final XmlMapper soapXmlMapper;

    @Override
    public void configureHttpMessageCodecs(ServerCodecConfigurer configurer) {
        configurer.defaultCodecs().jackson2XmlEncoder(new Jackson2XmlEncoder(soapXmlMapper));
        configurer.defaultCodecs().jackson2XmlDecoder(new Jackson2XmlDecoder(soapXmlMapper));
    }
}
