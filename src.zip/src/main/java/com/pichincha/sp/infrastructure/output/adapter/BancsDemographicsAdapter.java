package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.bnc.apiclient.dto.request.BancsHeaders;
import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.request.user.BancsUser;
import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.application.port.output.DemographicsCorePort;
import com.pichincha.sp.domain.dto.BancsUserDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.output.adapter.mapper.BancsRequestMapper;
import com.pichincha.sp.infrastructure.output.adapter.mapper.BancsResponseMapper;
import com.pichincha.sp.infrastructure.output.adapter.validator.BancsResponseValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.Exceptions;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

@Repository
@RequiredArgsConstructor
public class BancsDemographicsAdapter implements DemographicsCorePort {

        private final BancsClientPort bancsClientPort;
    private final BancsResponseValidator responseValidator;
    private final BancsRequestMapper requestMapper;
    private final BancsResponseMapper responseMapper;

        @Value("${wsclientes0061.bancs.connector-exception-prefix:ESB-%2% }")
        private String connectorExceptionPrefix = "ESB-%2% ";

        @Value("${wsclientes0061.bancs.timeout-message:Tiempo de espera terminado sin respuesta}")
        private String bancsTimeoutMessage = "Tiempo de espera terminado sin respuesta";

        @Value("${wsclientes0061.bancs.connector-exception-code:9928}")
        private String connectorExceptionCode = "9928";

        @Value("${wsclientes0061.bancs.timeout-code:9920}")
        private String bancsTimeoutCode = "9920";

        @Value("${wsclientes0061.soap.fatal-type:FATAL}")
        private String soapFatalType = "FATAL";

        @Value("${wsclientes0061.bancs.backend-code-esb:00638}")
        private String bancsBackendCodeEsb = "00638";

        @Value("${wsclientes0061.bancs.backend-code-business:00045}")
        private String bancsBackendCodeBusiness = "00045";

        @Value("${wsclientes0061.validation.customer-not-found-code:0282}")
        private String customerNotFoundCode = "0282";

        @Value("${wsclientes0061.validation.customer-not-found-message:NO SE ENCONTRARON REGISTROS DEL CLIENTE}")
        private String customerNotFoundMessage = "NO SE ENCONTRARON REGISTROS DEL CLIENTE";

        @Value("${wsclientes0061.soap.error-type:ERROR}")
        private String soapErrorType = "ERROR";

        @Value("${wsclientes0061.soap.transaction-id:061406}")
        private String soapTransactionId = "061406";

    @BpLogger
    @Override
    public Mono<DemographicsResponseDto> execute(DemographicsRequestDto request) {
        BancsRequest<BancsDemographicsRequest> bancsRequest = buildBancsRequest(request);

        return bancsClientPort.call(bancsRequest, BancsDemographicsResponse.class)
                .map(response -> responseValidator.extractBody(response, request.getResourceId()))
                .map(responseMapper::toDomain)
                .onErrorResume(BusinessException.class, Mono::error)
                .onErrorResume(TimeoutException.class, ex -> Mono.error(buildTimeoutException(request)))
                .onErrorResume(WebClientResponseException.class, ex -> Mono.error(mapConnectorException(ex, request)))
                .onErrorResume(WebClientRequestException.class, ex -> Mono.error(mapConnectorException(ex, request)))
                                .onErrorResume(Exception.class, ex -> {
                                        if (ex instanceof BusinessException businessException) {
                                                return Mono.error(businessException);
                                        }
                                        Throwable unwrapped = Exceptions.unwrap(ex);
                                        if (unwrapped instanceof TimeoutException) {
                                                return Mono.error(buildTimeoutException(request));
                                        }
                                        return Mono.error(mapConnectorException(ex, request));
                                });
    }

        private BusinessException mapConnectorException(Throwable ex, DemographicsRequestDto request) {
                if (isCustomerDomainOrNotFoundError(ex)) {
                        return new BusinessException(
                                        customerNotFoundCode,
                                        customerNotFoundMessage,
                                        soapErrorType,
                                        request.getResourceId(),
                                        InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                                        bancsBackendCodeBusiness
                        );
                }
                if (isRequestBodyValidationError(ex)) {
                        return new BusinessException(
                                        connectorExceptionCode,
                                        connectorExceptionPrefix + resolveConnectorMessage(ex),
                                        soapErrorType,
                                        request.getResourceId(),
                                        InfrastructureBusinessConstants.COMPONENT_BANCS_ADAPTER,
                                        bancsBackendCodeEsb
                        );
                }
                return new BusinessException(
                                connectorExceptionCode,
                                connectorExceptionPrefix + resolveConnectorMessage(ex),
                                soapFatalType,
                                request.getResourceId(),
                                InfrastructureBusinessConstants.COMPONENT_BANCS_ADAPTER,
                                bancsBackendCodeEsb
                );
        }

        private String resolveConnectorMessage(Throwable ex) {
                return buildConnectorDetails(ex).trim();
        }

        private String buildConnectorDetails(Throwable ex) {
                StringBuilder details = new StringBuilder();
                if (ex.getMessage() != null) {
                        details.append(ex.getMessage());
                }
                if (ex instanceof WebClientResponseException responseException) {
                        details.append(' ');
                        details.append(responseException.getResponseBodyAsString(StandardCharsets.UTF_8));
                }
                return details.toString();
        }

        private boolean isCustomerDomainOrNotFoundError(Throwable ex) {
                return BancsIntegrationErrorSupport.isCustomerDomainOrNotFoundError(buildConnectorDetails(ex));
        }

        private boolean isRequestBodyValidationError(Throwable ex) {
                return BancsIntegrationErrorSupport.isRequestBodyValidationError(buildConnectorDetails(ex));
        }

        private BusinessException buildTimeoutException(DemographicsRequestDto request) {
                return new BusinessException(
                                bancsTimeoutCode,
                                bancsTimeoutMessage,
                                soapFatalType,
                                request.getResourceId(),
                                InfrastructureBusinessConstants.COMPONENT_BANCS_TX,
                                bancsBackendCodeEsb
                );
        }

    private BancsRequest<BancsDemographicsRequest> buildBancsRequest(DemographicsRequestDto request) {
        BancsUserDataDto bancsUserData = request.getBancsUser();
        BancsHeaders bancsHeaders = bancsUserData != null
                ? BancsHeaders.builder()
                .bancsUser(BancsUser.builder()
                        .teller(bancsUserData.getTeller())
                        .terminal(bancsUserData.getTerminal())
                        .institution(bancsUserData.getInstitution())
                        .branch(bancsUserData.getBranch())
                        .workstation(bancsUserData.getWorkstation())
                        .channel(bancsUserData.getChannel())
                        .application(bancsUserData.getApplication())
                        .build())
                .build()
                : null;

        return BancsRequest.<BancsDemographicsRequest>builder()
                .transactionId(soapTransactionId)
                .header(bancsHeaders)
                .body(requestMapper.toBancsRequest(request))
                .build();
    }
}
