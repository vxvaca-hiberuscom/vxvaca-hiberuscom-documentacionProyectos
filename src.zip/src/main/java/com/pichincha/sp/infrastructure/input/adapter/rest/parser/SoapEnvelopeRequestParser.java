package com.pichincha.sp.infrastructure.input.adapter.rest.parser;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.validator.DemograficaElementOrderValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SoapEnvelopeRequestParser {

    private final XmlMapper soapXmlMapper;
    private final DemograficaElementOrderValidator demograficaElementOrderValidator;

    public SoapEnvelopeRequest parse(String rawRequest) {
        demograficaElementOrderValidator.validate(rawRequest);
        try {
            return soapXmlMapper.readValue(rawRequest, SoapEnvelopeRequest.class);
        } catch (JsonProcessingException ex) {
            throw new SoapInputFaultException();
        }
    }
}
