package com.pichincha.sp.infrastructure.input.adapter.rest.validator;

import com.pichincha.sp.domain.exception.SoapInputFaultException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class DemograficaElementOrderValidator {

    private static final Pattern DEMOGRAFICA_BLOCK = Pattern.compile(
            "<(?:[\\w]+:)?demografica\\b[^>]*>([\\s\\S]*?)</(?:[\\w]+:)?demografica>",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern ELEMENT_NAME = Pattern.compile(
            "<(?:[\\w]+:)?([a-zA-Z][\\w-]*)\\b"
    );

    public void validate(String soapXml) {
        if (soapXml == null || soapXml.isBlank()) {
            return;
        }

        Matcher blockMatcher = DEMOGRAFICA_BLOCK.matcher(soapXml);
        if (!blockMatcher.find()) {
            return;
        }

        validateSequence(extractDirectChildElementNames(blockMatcher.group(1)));
    }

    private List<String> extractDirectChildElementNames(String demograficaContent) {
        List<String> elements = new ArrayList<>();
        Matcher matcher = ELEMENT_NAME.matcher(demograficaContent);
        while (matcher.find()) {
            elements.add(matcher.group(1));
        }
        return elements;
    }

    private void validateSequence(List<String> actualElements) {
        int lastIndex = -1;
        for (String element : actualElements) {
            int index = DemograficaElementOrder.XSD_SEQUENCE.indexOf(element);
            if (index == -1) {
                throw new SoapInputFaultException(element);
            }
            if (index <= lastIndex) {
                throw new SoapInputFaultException();
            }
            lastIndex = index;
        }
    }
}
