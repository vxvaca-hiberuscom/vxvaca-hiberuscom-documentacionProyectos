package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.impl.SoapOperationService;
import com.pichincha.sp.infrastructure.input.adapter.rest.parser.SoapEnvelopeRequestParser;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("${wsclientes0061.soap.path:/IntegrationBus/soap/WSClientes0061}")
@RequiredArgsConstructor
public class WSClientes0061Controller {

    private final SoapOperationService soapOperationService;
    private final SoapEnvelopeRequestParser soapEnvelopeRequestParser;

    @PostMapping(
            consumes = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE},
            produces = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE}
    )
    @BpLogger
    public Mono<SoapEnvelopeResponse> procesarOperacion(@RequestBody String rawRequest) {
        return Mono.fromCallable(() -> soapEnvelopeRequestParser.parse(rawRequest))
                .flatMap(soapOperationService::process);
    }
}
