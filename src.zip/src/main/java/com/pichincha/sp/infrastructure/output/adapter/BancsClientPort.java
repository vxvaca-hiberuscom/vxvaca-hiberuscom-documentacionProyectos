package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import reactor.core.publisher.Mono;

public interface BancsClientPort {

    <T> Mono<BancsResponse<T>> call(BancsRequest<?> request, Class<T> responseType);
}
