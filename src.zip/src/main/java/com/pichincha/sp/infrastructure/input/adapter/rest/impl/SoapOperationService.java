package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.OperacionDemograficosCliente51;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapBodyRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class SoapOperationService {

    private final ProcessDemographicsPort processDemographicsPort;
    private final SoapDemographicsMapper soapDemographicsMapper;

    @Value("${wsclientes0061.soap.body-null-message:SOAP body is null}")
    private String soapBodyNullMessage = "SOAP body is null";

    @Value("${wsclientes0061.soap.operation-not-found-message:No valid SOAP operation found in Body}")
    private String soapOperationNotFoundMessage = "No valid SOAP operation found in Body";

    public Mono<SoapEnvelopeResponse> process(SoapEnvelopeRequest request) {
        return Mono.defer(() -> {
                    SoapBodyRequest body = request != null ? request.getBody() : null;
                    if (body == null) {
                        return Mono.just(soapDemographicsMapper.toErrorSoapEnvelope(soapBodyNullMessage));
                    }

                    if (body.getOperacionDemograficosCliente51() == null) {
                        return Mono.just(soapDemographicsMapper.toErrorSoapEnvelope(soapOperationNotFoundMessage));
                    }

                    GenericHeaderIn requestHeader = body.getOperacionDemograficosCliente51().getHeaderIn();
                    OperacionDemograficosCliente51 operation = body.getOperacionDemograficosCliente51();

                    return Mono.fromCallable(() -> soapDemographicsMapper.toDomain(operation))
                            .flatMap(domainRequest -> processDemographicsPort.execute(domainRequest)
                                    .map(response -> soapDemographicsMapper.toSoapEnvelopeResponse(response, requestHeader)))
                            .onErrorResume(BusinessException.class,
                                    ex -> Mono.just(soapDemographicsMapper.toErrorSoapEnvelope(ex, requestHeader)));
                });
    }
}