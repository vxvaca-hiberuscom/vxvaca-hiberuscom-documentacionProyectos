package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapBodyRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class SoapOperationService {

    private final ProcessDemographicsPort processDemographicsPort;
    private final SoapDemographicsMapper soapDemographicsMapper;

    @Value("${wsclientes0061.soap.body-null-message:SOAP body is null}")
    private String soapBodyNullMessage = "SOAP body is null";

    @Value("${wsclientes0061.soap.operation-not-found-message:No valid SOAP operation found in Body}")
    private String soapOperationNotFoundMessage = "No valid SOAP operation found in Body";

    public Mono<SoapEnvelopeResponse> process(SoapEnvelopeRequest request) {
        return Mono.defer(() -> {
                    if (request == null || request.getBody() == null) {
                        throw new SoapInputFaultException(soapBodyNullMessage);
                    }

                    SoapBodyRequest body = request.getBody();
                    if (body.getOperacionDemograficosCliente51() == null) {
                        throw new SoapInputFaultException(soapOperationNotFoundMessage);
                    }

                    GenericHeaderIn requestHeader = body.getOperacionDemograficosCliente51().getHeaderIn();
                    DemographicsRequestDto domainRequest = soapDemographicsMapper.toDomain(body.getOperacionDemograficosCliente51());

                    return processDemographicsPort.execute(domainRequest)
                            .map(response -> soapDemographicsMapper.toSoapEnvelopeResponse(response, requestHeader))
                            .onErrorResume(BusinessException.class,
                                    ex -> Mono.just(soapDemographicsMapper.toErrorSoapEnvelope(ex, requestHeader)));
                })
                .onErrorResume(BusinessException.class,
                        ex -> Mono.just(soapDemographicsMapper.toErrorSoapEnvelope(ex)));
    }
}