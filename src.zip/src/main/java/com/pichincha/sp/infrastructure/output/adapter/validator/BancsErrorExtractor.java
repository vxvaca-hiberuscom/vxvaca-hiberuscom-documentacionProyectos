package com.pichincha.sp.infrastructure.output.adapter.validator;

import com.pichincha.bnc.apiclient.dto.response.BancsError;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;

import java.lang.reflect.Method;

final class BancsErrorExtractor {

    private BancsErrorExtractor() {
    }

    static String extractMessage(BancsError error) {
        return firstNonBlank(
                error != null ? error.message() : null,
                invokeString(error, "description"),
                invokeString(error, "detail")
        );
    }

    static String extractBusinessCode(BancsError error) {
        if (error == null) {
            return InfrastructureBusinessConstants.EMPTY;
        }
        if (isBusinessCode(error.code())) {
            return InfrastructureBusinessConstants.formatNumericErrorCode(error.code());
        }
        return firstNonBlank(
                formatIfNumeric(invokeString(error, "businessCode")),
                formatIfNumeric(invokeString(error, "coreCode")),
                formatIfNumeric(invokeString(error, "errorCode")),
                formatIfNumeric(invokeString(error, "codError"))
        );
    }

    static boolean isHttpStatusCode(String code) {
        if (code == null || code.isBlank()) {
            return false;
        }
        return code.trim().matches("[45]\\d{2}");
    }

    private static boolean isBusinessCode(String code) {
        return code != null && !code.isBlank() && !isHttpStatusCode(code);
    }

    private static String formatIfNumeric(String code) {
        if (code == null || code.isBlank()) {
            return InfrastructureBusinessConstants.EMPTY;
        }
        if (code.trim().matches("\\d+")) {
            return InfrastructureBusinessConstants.formatNumericErrorCode(code);
        }
        return code.trim();
    }

    private static String invokeString(BancsError error, String methodName) {
        if (error == null) {
            return null;
        }
        try {
            Method method = error.getClass().getMethod(methodName);
            Object value = method.invoke(error);
            return value != null ? String.valueOf(value) : null;
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return InfrastructureBusinessConstants.EMPTY;
    }
}
