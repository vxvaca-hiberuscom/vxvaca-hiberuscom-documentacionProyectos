package com.pichincha.sp.infrastructure.input.adapter.rest.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.pichincha.sp.generated.OperacionDemograficosCliente51;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapBodyRequest {

    @XmlElement(name = "OperacionDemograficosCliente51", namespace = "http://bpichincha.com/servicios")
    @JacksonXmlProperty(localName = "OperacionDemograficosCliente51", namespace = "http://bpichincha.com/servicios")
    private OperacionDemograficosCliente51 operacionDemograficosCliente51;
}