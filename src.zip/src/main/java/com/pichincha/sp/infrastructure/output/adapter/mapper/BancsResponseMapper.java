package com.pichincha.sp.infrastructure.output.adapter.mapper;

import com.pichincha.sp.application.constants.ApplicationBusinessConstants;
import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.infrastructure.constants.InfrastructureBusinessConstants;
import com.pichincha.sp.infrastructure.output.adapter.BancsDemographicsResponse;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Value;

import java.util.regex.Pattern;

@Mapper(componentModel = "spring")
public abstract class BancsResponseMapper {

    private static final Pattern EIGHT_DIGIT_DATE_PATTERN = Pattern.compile("\\d{8}");

    @Value("${wsclientes0061.bancs.response-error-message:Error processing BANCS response}")
    private String bancsResponseErrorMessage = "Error processing BANCS response";

    @Value("${wsclientes0061.validation.customer-not-found-code:0282}")
    private String customerNotFoundCode = "0282";

    @Value("${wsclientes0061.validation.customer-not-found-message:NO SE ENCONTRARON REGISTROS DEL CLIENTE}")
    private String customerNotFoundMessage = "NO SE ENCONTRARON REGISTROS DEL CLIENTE";

    public DemographicsResponseDto toDomain(BancsDemographicsResponse response) {
        validateCoreError(response);
        DemographicDataDto data = toDemographicData(response);

        return DemographicsResponseDto.builder()
                .code(InfrastructureBusinessConstants.SUCCESS_CODE)
                .message(InfrastructureBusinessConstants.SUCCESS_MESSAGE)
                .demographicData(data)
                .build();
    }

    @Mapping(target = "countryOfBirth", source = "countryOfBirth")
    @Mapping(target = "birthStateProvince", source = "birthStateProvince")
    @Mapping(target = "birthCity", source = "birthCity")
    @Mapping(target = "birthDate", expression = "java(formatBirthDateValue(response.birthDate()))")
    @Mapping(target = "age", expression = "java(toNullableString(response.age()))")
    @Mapping(target = "gender", source = "gender")
    @Mapping(target = "maritalStatus", source = "maritalStatus")
    @Mapping(target = "propertySeparation", source = "propertySeparation")
    @Mapping(target = "educationLevel", source = "educationLevel")
    @Mapping(target = "profession", source = "profession")
    @Mapping(target = "familyDependents", expression = "java(toNullableString(response.familyDependents()))")
    @Mapping(target = "housingType", source = "housingType")
    @Mapping(target = "legalDeedsAtAddress", source = "legalDeedsAtAddress")
    @Mapping(target = "basicServicesAtAddress", source = "basicServicesAtAddress")
    @Mapping(target = "houseOwnerName", source = "houseOwnerName")
    @Mapping(target = "addressFeatures", source = "addressFeatures")
    @Mapping(target = "residenceTime", source = "residenceTime")
    @Mapping(target = "clientAddressSector", source = "clientAddressSector")
    @Mapping(target = "cif", ignore = true)
    @Mapping(target = "operation", ignore = true)
    @Mapping(target = "naturalCustomer", ignore = true)
    protected abstract DemographicDataDto toDemographicData(BancsDemographicsResponse response);

    private void validateCoreError(BancsDemographicsResponse response) {
        if (response.coreErrorCode() != null && response.coreErrorCode() != 0) {
            String errorCode = formatCoreErrorCode(response.coreErrorCode());
            throw new BusinessException(
                    errorCode,
                    resolveCoreErrorMessage(response, errorCode),
                    InfrastructureBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                    InfrastructureBusinessConstants.COMPONENT_BANCS_VALIDATOR,
                    ApplicationBusinessConstants.BACKEND_BUSINESS
            );
        }
    }

    private String formatCoreErrorCode(Integer coreErrorCode) {
        return String.format("%04d", coreErrorCode);
    }

    private String resolveCoreErrorMessage(BancsDemographicsResponse response, String errorCode) {
        if (response.coreErrorDescription() != null && !response.coreErrorDescription().isBlank()) {
            return response.coreErrorDescription();
        }
        if (customerNotFoundCode.equals(errorCode)) {
            return customerNotFoundMessage;
        }
        return bancsResponseErrorMessage;
    }

    protected static String toNullableString(Integer value) {
        return value == null ? null : String.valueOf(value);
    }

    protected static String formatBirthDateValue(String birthDate) {
        if (birthDate == null || birthDate.isBlank()) {
            return InfrastructureBusinessConstants.EMPTY;
        }
        String trimmedBirthDate = birthDate.trim();
        if (!EIGHT_DIGIT_DATE_PATTERN.matcher(trimmedBirthDate).matches()) {
            return trimmedBirthDate;
        }
        return trimmedBirthDate.substring(0, 2)
                + "/"
                + trimmedBirthDate.substring(2, 4)
                + "/"
                + trimmedBirthDate.substring(4, 8);
    }
}
