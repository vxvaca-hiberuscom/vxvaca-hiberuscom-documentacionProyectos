package com.pichincha.sp.infrastructure.input.adapter.rest.support;

import com.pichincha.sp.generated.Journals;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

import java.io.StringReader;

public final class JournalsXmlSupport {

    private static final String DEFAULT_JOURNALS_XML = """
            <journals xmlns="http://bpichincha.com/servicios">
                <journal><valor></valor></journal>
            </journals>
            """;

    private JournalsXmlSupport() {
    }

    public static Journals createDefault() {
        try {
            Unmarshaller unmarshaller = JAXBContext.newInstance(Journals.class).createUnmarshaller();
            return (Journals) unmarshaller.unmarshal(new StringReader(DEFAULT_JOURNALS_XML));
        } catch (JAXBException ex) {
            throw new IllegalStateException("Unable to initialize default journals structure", ex);
        }
    }
}
