package com.pichincha.sp.infrastructure.output.adapter;

final class BancsIntegrationErrorSupport {

    private BancsIntegrationErrorSupport() {
    }

    static boolean isCustomerDomainOrNotFoundError(String details) {
        if (details == null || details.isBlank()) {
            return false;
        }
        String upperDetails = details.toUpperCase();
        if (upperDetails.contains("NO SE ENCONTRARON REGISTROS DEL CLIENTE")) {
            return true;
        }
        if (details.contains("Error on: Value [")) {
            return true;
        }
        return details.contains("businessMessage=") && details.contains("Error on:");
    }

    static boolean isRequestBodyValidationError(String details) {
        if (details == null || details.isBlank()) {
            return false;
        }
        return details.contains("httpStatus=400") && details.contains("Body no coincide");
    }
}
