package com.pichincha.sp.infrastructure.input.adapter.rest.controller;

import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.domain.exception.SoapInputFaultException;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.SoapDemographicsMapper;
import com.pichincha.sp.infrastructure.input.adapter.rest.support.SoapEnvelopeErrorSupport;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.core.codec.DecodingException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ServerWebInputException;

@RestControllerAdvice(basePackages = "com.pichincha.sp.infrastructure.input.adapter.rest.controller")
@Order(-1)
@RequiredArgsConstructor
public class SoapExceptionHandler {

    private final SoapDemographicsMapper soapDemographicsMapper;

    @Value("${wsclientes0061.soap.fault-code:soapenv:Server}")
    private String soapFaultCode = "soapenv:Server";

    @Value("${wsclientes0061.soap.fault-message-missing-teller-tag:BIP3113E: Exception detected in message flow com.bpichincha.esb.wsclientes0061.WSClientes0061.SOAP Input (integration node TCSBRKR1_BP)}")
    private String soapFaultMessage = "BIP3113E: Exception detected in message flow com.bpichincha.esb.wsclientes0061.WSClientes0061.SOAP Input (integration node TCSBRKR1_BP)";

    @Value("${wsclientes0061.soap.fault-message-envelope-creation:Exception during creation of SOAP envelope}")
    private String soapFaultEnvelopeCreationMessage = "Exception during creation of SOAP envelope";

    @Value("${wsclientes0061.soap.default-error-message:Unexpected SOAP processing error}")
    private String defaultErrorMessage = "Unexpected SOAP processing error";

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<SoapEnvelopeResponse> handleBusinessException(BusinessException ex) {
        SoapEnvelopeResponse response = soapDemographicsMapper.toErrorSoapEnvelope(ex);

        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_XML)
                .body(response);
    }

    @ExceptionHandler(SoapInputFaultException.class)
    public ResponseEntity<String> handleSoapInputFault(RuntimeException ex) {
        return buildSoapFaultResponse(soapFaultMessage);
    }

    @ExceptionHandler({ServerWebInputException.class, DecodingException.class})
    public ResponseEntity<String> handleMalformedSoapEnvelope(Exception ex) {
        return buildSoapFaultResponse(soapFaultEnvelopeCreationMessage);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleSoapExceptions(Exception ex) {
        if (SoapEnvelopeErrorSupport.isEnvelopeParsingError(ex)) {
            return buildSoapFaultResponse(soapFaultEnvelopeCreationMessage);
        }

        SoapEnvelopeResponse response = soapDemographicsMapper.toErrorSoapEnvelope(defaultErrorMessage);

        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_XML)
                .body(response);
    }

    private ResponseEntity<String> buildSoapFaultResponse(String faultMessage) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .contentType(MediaType.TEXT_XML)
                .body(buildSoapFaultEnvelope(faultMessage));
    }

    private String buildSoapFaultEnvelope(String faultMessage) {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
                    <soapenv:Body>
                        <soapenv:Fault>
                            <faultcode>%s</faultcode>
                            <faultstring>%s</faultstring>
                        </soapenv:Fault>
                    </soapenv:Body>
                </soapenv:Envelope>
                """.formatted(soapFaultCode, faultMessage);
    }
}
