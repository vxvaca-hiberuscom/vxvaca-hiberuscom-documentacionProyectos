package com.pichincha.sp.domain.constants;

public final class DomainBusinessConstants {

    private DomainBusinessConstants() {
    }

    public static final String DEFAULT_SUCCESS_CODE = "0";
    public static final String DEFAULT_SUCCESS_MESSAGE = "Ok";
    public static final String DEFAULT_ERROR_CODE = "999";
}
