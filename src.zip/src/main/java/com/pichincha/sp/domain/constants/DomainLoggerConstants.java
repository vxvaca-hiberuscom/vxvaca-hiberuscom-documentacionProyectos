package com.pichincha.sp.domain.constants;

public final class DomainLoggerConstants {

    private DomainLoggerConstants() {
    }

    public static final String LOG_BUSINESS_EXCEPTION = "Business exception raised: code={}, resource={}, component={}, backend={}";
}
