package com.pichincha.sp.domain.exception;

import lombok.Getter;

@Getter
public class BusinessException extends RuntimeException {

    private final String code;
    private final String type;
    private final String resource;
    private final String component;
    private final String backend;

    public BusinessException(String code, String message, String resource, String component, String backend) {
        this(code, message, "ERROR", resource, component, backend);
    }

    public BusinessException(String code, String message, String type, String resource, String component, String backend) {
        super(message);
        this.code = code;
        this.type = type;
        this.resource = resource;
        this.component = component;
        this.backend = backend;
    }
}
