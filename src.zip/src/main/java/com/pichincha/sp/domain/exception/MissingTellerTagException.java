package com.pichincha.sp.domain.exception;

public class MissingTellerTagException extends RuntimeException {

    public MissingTellerTagException(String message) {
        super(message);
    }
}
