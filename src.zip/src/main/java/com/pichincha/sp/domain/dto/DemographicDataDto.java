package com.pichincha.sp.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class DemographicDataDto {
    String cif;
    String operation;
    String naturalCustomer;
    String countryOfBirth;
    String birthStateProvince;
    String birthCity;
    String birthDate;
    String age;
    String gender;
    String maritalStatus;
    String propertySeparation;
    String educationLevel;
    String profession;
    String familyDependents;
    String housingType;
    String legalDeedsAtAddress;
    String basicServicesAtAddress;
    String houseOwnerName;
    String addressFeatures;
    String residenceTime;
    String clientAddressSector;
}
