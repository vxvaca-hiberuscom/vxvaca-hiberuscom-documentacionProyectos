package com.pichincha.sp.domain.exception;

public class SoapInputFaultException extends RuntimeException {

    public SoapInputFaultException() {
        super();
    }

    public SoapInputFaultException(String message) {
        super(message);
    }
}
