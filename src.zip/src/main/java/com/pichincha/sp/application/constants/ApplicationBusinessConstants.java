package com.pichincha.sp.application.constants;

import java.util.Set;

public final class ApplicationBusinessConstants {

    private ApplicationBusinessConstants() {
    }

    public static final String COMPONENT_DEMOGRAPHICS_SERVICE = "DEMOGRAPHICS_SERVICE";
    public static final String BACKEND_BANCS = "BANCS";
    public static final String RESOURCE_DEMOGRAPHICS_OPERATION = "WSClientes0061/OperacionDemograficosCliente61";
    public static final String COMPONENT_VALIDATION_OPERATION = "OperacionDemograficosCliente61";
    public static final String BACKEND_VALIDATION = "00638";
    public static final String BACKEND_BUSINESS = "00045";

    public static final Set<String> ALLOWED_OPERATIONS = Set.of("01", "02", "03");

    public static final int CIF_LENGTH = 16;
    public static final int OPERATION_LENGTH = 2;
    public static final int THREE_DIGITS_LENGTH = 3;

    public static final String BOOLEAN_TRUE_TEXT = "TRUE";
    public static final String BOOLEAN_FALSE_TEXT = "FALSE";
    public static final String NATURAL_CUSTOMER_TRUE = "T";
    public static final String NATURAL_CUSTOMER_FALSE = "F";

    public static final String SUCCESS_CODE = "0";
    public static final String SUCCESS_MESSAGE = "Ok";
}
