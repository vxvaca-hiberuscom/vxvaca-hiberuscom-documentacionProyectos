package com.pichincha.sp.application.port.input;

import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import reactor.core.publisher.Mono;

public interface ProcessDemographicsPort {
    Mono<DemographicsResponseDto> execute(DemographicsRequestDto request);
}
