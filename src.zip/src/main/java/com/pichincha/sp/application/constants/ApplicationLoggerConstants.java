package com.pichincha.sp.application.constants;

public final class ApplicationLoggerConstants {

    private ApplicationLoggerConstants() {
    }

    public static final String LOG_START_PROCESS_DEMOGRAPHICS_SERVICE = "Start demographics processing for resource={}";
    public static final String LOG_COMPLETE_PROCESS_DEMOGRAPHICS_SERVICE = "Demographics processing completed for resource={}";
    public static final String LOG_ERROR_PROCESS_DEMOGRAPHICS_SERVICE = "Error during demographics processing for resource={}";
    public static final String LOG_WARN_NULL_RESPONSE = "Null response received from core service for resource={}";
}
