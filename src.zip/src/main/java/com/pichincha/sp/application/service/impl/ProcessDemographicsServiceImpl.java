package com.pichincha.sp.application.service.impl;

import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.application.constants.ApplicationBusinessConstants;
import com.pichincha.sp.application.port.input.ProcessDemographicsPort;
import com.pichincha.sp.application.port.output.DemographicsCorePort;
import com.pichincha.sp.domain.dto.DemographicDataDto;
import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Set;

@Service
@RequiredArgsConstructor
public class ProcessDemographicsServiceImpl implements ProcessDemographicsPort {
    private static final Set<String> ALLOWED_OPERATIONS = ApplicationBusinessConstants.ALLOWED_OPERATIONS;

    private final DemographicsCorePort demographicsCorePort;

    @Value("${wsclientes0061.validation.body-required-message:Body input is required}")
    private String errorMessageBodyRequired = "Body input is required";

    @Value("${wsclientes0061.validation.body-required-code:1}")
    private String errorCodeBodyRequired = "1";

    @Value("${wsclientes0061.validation.cif-invalid-message:Valor del campo cif vacío o inválido}")
    private String errorMessageCifInvalid = "Valor del campo cif vacío o inválido";

    @Value("${wsclientes0061.validation.customer-not-found-message:NO SE ENCONTRARON REGISTROS DEL CLIENTE}")
    private String errorMessageCustomerNotFound = "NO SE ENCONTRARON REGISTROS DEL CLIENTE";

    @Value("${wsclientes0061.validation.customer-not-found-code:0282}")
    private String errorCodeCustomerNotFound = "0282";

    @Value("${wsclientes0061.validation.operation-required-message:Valor del campo operacion vacío o inválido}")
    private String errorMessageOperationRequired = "Valor del campo operacion vacío o inválido";

    @Value("${wsclientes0061.validation.operation-required-code:2}")
    private String errorCodeOperationRequired = "2";

    @Value("${wsclientes0061.validation.natural-customer-required-message:Valor del campo clienteNatural vacío o inválido}")
    private String errorMessageNaturalCustomerRequired = "Valor del campo clienteNatural vacío o inválido";

    @Value("${wsclientes0061.validation.natural-customer-required-code:3}")
    private String errorCodeNaturalCustomerRequired = "3";

    @Value("${wsclientes0061.validation.operation-invalid-message:Valor del campo operacion  inválido}")
    private String errorMessageOperationInvalid = "Valor del campo operacion  inválido";

    @Value("${wsclientes0061.validation.operation-invalid-code:4}")
    private String errorCodeOperationInvalid = "4";

    @BpLogger
    @Override
    public Mono<DemographicsResponseDto> execute(DemographicsRequestDto request) {
        return Mono.defer(() -> {
                    validateRequest(request);
                    return demographicsCorePort.execute(normalizeRequest(request));
                })
                .map(ProcessDemographicsServiceImpl::normalizeResponse);
    }

    private void validateRequest(DemographicsRequestDto request) {
        if (request == null || request.getDemographicData() == null) {
            throw new BusinessException(
                    errorCodeBodyRequired,
                    errorMessageBodyRequired,
                    ApplicationBusinessConstants.RESOURCE_DEMOGRAPHICS_OPERATION,
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_VALIDATION
            );
        }

        DemographicDataDto data = request.getDemographicData();
        if (data.getCif() == null) {
            throw new BusinessException(
                    errorCodeCustomerNotFound,
                    errorMessageCustomerNotFound,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_BUSINESS
            );
        }

        if (data.getCif() != null && data.getCif().isBlank()) {
            throw new BusinessException(
                    errorCodeBodyRequired,
                errorMessageCifInvalid,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_VALIDATION
            );
        }
        if (!isCifWithinDomain(data.getCif())) {
            throw new BusinessException(
                    errorCodeCustomerNotFound,
                    errorMessageCustomerNotFound,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_BUSINESS
            );
        }
        if (data.getOperation() == null) {
            throw new BusinessException(
                    errorCodeOperationInvalid,
                    errorMessageOperationInvalid,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_VALIDATION
            );
        }
        if (StringUtils.isBlank(data.getOperation())) {
            throw new BusinessException(
                    errorCodeOperationRequired,
                    errorMessageOperationRequired,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_VALIDATION
            );
        }
        if (!ALLOWED_OPERATIONS.contains(data.getOperation())) {
            throw new BusinessException(
                    errorCodeOperationInvalid,
                    errorMessageOperationInvalid,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_VALIDATION
            );
        }

        if (data.getNaturalCustomer() != null && StringUtils.isBlank(data.getNaturalCustomer())) {
            throw new BusinessException(
                    errorCodeNaturalCustomerRequired,
                    errorMessageNaturalCustomerRequired,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_VALIDATION
            );
        }

        if (data.getNaturalCustomer() != null && !isValidNaturalCustomerValue(data.getNaturalCustomer())) {
            throw new BusinessException(
                    errorCodeNaturalCustomerRequired,
                    errorMessageNaturalCustomerRequired,
                    request.getResourceId(),
                    ApplicationBusinessConstants.COMPONENT_VALIDATION_OPERATION,
                    ApplicationBusinessConstants.BACKEND_VALIDATION
            );
        }
    }

    private DemographicsRequestDto normalizeRequest(DemographicsRequestDto request) {
        DemographicDataDto data = request.getDemographicData();
        String normalizedOperation = normalizeOperation(data.getOperation());
        boolean includeDemographicDetails = shouldIncludeDemographicDetails(normalizedOperation);

        DemographicDataDto normalized = data.toBuilder()
                .cif(normalizeCif(data.getCif()))
                .operation(normalizedOperation)
                .naturalCustomer(normalizeNaturalCustomer(data.getNaturalCustomer()))
                .countryOfBirth(retainWhenIncluded(includeDemographicDetails, data.getCountryOfBirth()))
                .birthStateProvince(retainWhenIncluded(includeDemographicDetails, data.getBirthStateProvince()))
                .birthCity(retainWhenIncluded(includeDemographicDetails, data.getBirthCity()))
                .birthDate(retainWhenIncluded(includeDemographicDetails, data.getBirthDate()))
                .age(padWhenIncluded(includeDemographicDetails, data.getAge()))
                .gender(retainWhenIncluded(includeDemographicDetails, data.getGender()))
                .maritalStatus(retainWhenIncluded(includeDemographicDetails, data.getMaritalStatus()))
                .propertySeparation(retainWhenIncluded(includeDemographicDetails, data.getPropertySeparation()))
                .educationLevel(retainWhenIncluded(includeDemographicDetails, data.getEducationLevel()))
                .profession(retainWhenIncluded(includeDemographicDetails, data.getProfession()))
                .familyDependents(padWhenIncluded(includeDemographicDetails, data.getFamilyDependents()))
                .housingType(retainWhenIncluded(includeDemographicDetails, data.getHousingType()))
                .legalDeedsAtAddress(retainWhenIncluded(includeDemographicDetails, data.getLegalDeedsAtAddress()))
                .basicServicesAtAddress(retainWhenIncluded(includeDemographicDetails, data.getBasicServicesAtAddress()))
                .houseOwnerName(retainWhenIncluded(includeDemographicDetails, data.getHouseOwnerName()))
                .addressFeatures(retainWhenIncluded(includeDemographicDetails, data.getAddressFeatures()))
                .residenceTime(retainWhenIncluded(includeDemographicDetails, data.getResidenceTime()))
                .clientAddressSector(retainWhenIncluded(includeDemographicDetails, data.getClientAddressSector()))
                .build();
        return request.toBuilder().demographicData(normalized).build();
    }

    private String normalizeOperation(String operation) {
        return StringUtils.leftPad(
                StringUtils.defaultString(operation),
                ApplicationBusinessConstants.OPERATION_LENGTH,
                '0'
        );
    }

    private static boolean shouldIncludeDemographicDetails(String normalizedOperation) {
        return "01".equals(normalizedOperation) || "03".equals(normalizedOperation);
    }

    private String normalizeCif(String cif) {
        return StringUtils.leftPad(
                StringUtils.defaultString(cif),
                ApplicationBusinessConstants.CIF_LENGTH,
                '0'
        );
    }

    private static boolean isCifWithinDomain(String cif) {
        String trimmedCif = cif.trim();
        if (!trimmedCif.matches("\\d+")) {
            return false;
        }
        return trimmedCif.length() <= ApplicationBusinessConstants.CIF_LENGTH;
    }

    private String normalizeNaturalCustomer(String naturalCustomer) {
        if (isNaturalCustomerTrue(naturalCustomer)) {
            return ApplicationBusinessConstants.NATURAL_CUSTOMER_TRUE;
        }
        return ApplicationBusinessConstants.NATURAL_CUSTOMER_FALSE;
    }

    private static String retainWhenIncluded(boolean includeDemographicDetails, String value) {
        if (includeDemographicDetails) {
            return value;
        }
        return null;
    }

    private String padWhenIncluded(boolean includeDemographicDetails, String value) {
        if (!includeDemographicDetails || StringUtils.isBlank(value)) {
            return null;
        }
        String trimmed = value.trim();
        if (!trimmed.matches("\\d{1,3}")) {
            return null;
        }
        return StringUtils.leftPad(trimmed, ApplicationBusinessConstants.THREE_DIGITS_LENGTH, '0');
    }

    private static boolean isValidNaturalCustomerValue(String naturalCustomer) {
        return ApplicationBusinessConstants.BOOLEAN_TRUE_TEXT.equalsIgnoreCase(naturalCustomer)
                || ApplicationBusinessConstants.BOOLEAN_FALSE_TEXT.equalsIgnoreCase(naturalCustomer)
                || ApplicationBusinessConstants.NATURAL_CUSTOMER_TRUE.equalsIgnoreCase(naturalCustomer)
                || ApplicationBusinessConstants.NATURAL_CUSTOMER_FALSE.equalsIgnoreCase(naturalCustomer);
    }

    private boolean isNaturalCustomerTrue(String naturalCustomer) {
        return ApplicationBusinessConstants.BOOLEAN_TRUE_TEXT.equalsIgnoreCase(StringUtils.defaultString(naturalCustomer))
                || ApplicationBusinessConstants.NATURAL_CUSTOMER_TRUE.equalsIgnoreCase(StringUtils.defaultString(naturalCustomer));
    }

    private static DemographicsResponseDto normalizeResponse(DemographicsResponseDto response) {
        if (response == null) {
            return DemographicsResponseDto.builder()
                .code(ApplicationBusinessConstants.SUCCESS_CODE)
                .message(ApplicationBusinessConstants.SUCCESS_MESSAGE)
                .build();
        }
        return response;
    }
}
