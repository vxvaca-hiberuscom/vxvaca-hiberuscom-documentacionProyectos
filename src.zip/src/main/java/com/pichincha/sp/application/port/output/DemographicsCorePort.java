package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.DemographicsRequestDto;
import com.pichincha.sp.domain.dto.DemographicsResponseDto;
import reactor.core.publisher.Mono;

public interface DemographicsCorePort {
    Mono<DemographicsResponseDto> execute(DemographicsRequestDto request);
}
